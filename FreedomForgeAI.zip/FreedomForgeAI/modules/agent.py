# ============================================================
#  FreedomForge AI — modules/agent.py
#  Full computer control agent — file ops, apps, system, shell
#
#  Three modes:
#    OFF       — no commands execute (default)
#    SUPERVISED — agent asks for confirmation before each action
#    FULL      — agent runs everything without asking
#
#  Safety: catastrophic commands are ALWAYS blocked regardless
#  of mode. The AI sees results and can chain commands.
# ============================================================

import os
import re
import shlex
import shutil
import subprocess
import threading
import platform
from pathlib import Path
from typing import Callable, Optional
from core import logger

MODULE_NAME = "agent"

# ── Modes ────────────────────────────────────────────────────
MODE_OFF        = "off"
MODE_SUPERVISED = "supervised"
MODE_FULL       = "full"

_mode = MODE_OFF

# ── Always blocked — these can brick your system ─────────────
HARD_BLOCKED = [
    "rm -rf /",
    "rm -rf /*",
    "mkfs",
    "dd if=",
    ":(){:|:&};:",     # fork bomb
    "chmod -R 777 /",
    "> /dev/sda",
    "mv /* /dev/null",
    "format c:",
    "del /f /s /q c:\\",
]

# ── Dangerous patterns that require FULL mode ────────────────
DANGEROUS_PATTERNS = [
    r"sudo\s+rm",
    r"rm\s+-rf\s+[/~]",
    r"chmod\s+.*\s+/",
    r"chown\s+.*\s+/",
    r"shutdown",
    r"reboot",
    r"systemctl\s+(stop|disable|mask)",
    r"kill\s+-9",
    r"pkill",
    r"iptables",
]


def set_mode(mode: str) -> None:
    global _mode
    if mode in (MODE_OFF, MODE_SUPERVISED, MODE_FULL):
        _mode = mode
        logger.info(f"Agent mode: {_mode}")


def get_mode() -> str:
    return _mode


def is_enabled() -> bool:
    return _mode != MODE_OFF


def set_enabled(enabled: bool) -> None:
    """Legacy toggle — maps to supervised mode."""
    set_mode(MODE_SUPERVISED if enabled else MODE_OFF)


# ── Safety check ─────────────────────────────────────────────

def check_command(command: str) -> tuple:
    """Check command safety. Returns (allowed, reason, needs_confirm)."""
    cmd_lower = command.lower().strip()

    # Hard blocked — always
    for blocked in HARD_BLOCKED:
        if blocked in cmd_lower:
            return False, f"Blocked: contains '{blocked}'", False

    # Dangerous — only in FULL mode, needs confirm in SUPERVISED
    for pattern in DANGEROUS_PATTERNS:
        if re.search(pattern, cmd_lower):
            if _mode == MODE_FULL:
                return True, "", False
            elif _mode == MODE_SUPERVISED:
                return True, f"Dangerous: matches '{pattern}'", True
            else:
                return False, f"Dangerous command — enable Full Control", False

    return True, "", (_mode == MODE_SUPERVISED)


# ── Built-in agent actions ───────────────────────────────────

def list_files(path: str = ".") -> str:
    """List files in a directory."""
    try:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            return f"Path not found: {p}"
        entries = sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
        lines = []
        for e in entries[:100]:
            kind = "📁" if e.is_dir() else "📄"
            try:
                size = e.stat().st_size
                if size > 1_000_000:
                    sz = f"{size / 1_000_000:.1f} MB"
                elif size > 1000:
                    sz = f"{size / 1000:.1f} KB"
                else:
                    sz = f"{size} B"
            except Exception:
                sz = "?"
            lines.append(f"  {kind}  {e.name}  ({sz})")
        header = f"📂 {p}\n{'─' * 40}\n"
        return header + "\n".join(lines) if lines else header + "  (empty)"
    except Exception as e:
        return f"Error: {e}"


def read_file(path: str, max_lines: int = 200) -> str:
    """Read a text file."""
    try:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            return f"File not found: {p}"
        if p.stat().st_size > 5_000_000:
            return f"File too large ({p.stat().st_size / 1_000_000:.1f} MB). Use head/tail."
        text = p.read_text(encoding="utf-8", errors="replace")
        lines = text.split("\n")
        if len(lines) > max_lines:
            return "\n".join(lines[:max_lines]) + f"\n\n... ({len(lines) - max_lines} more lines)"
        return text
    except Exception as e:
        return f"Error: {e}"


def write_file(path: str, content: str) -> str:
    """Write content to a file."""
    try:
        p = Path(path).expanduser().resolve()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"✅ Written: {p} ({len(content)} bytes)"
    except Exception as e:
        return f"Error: {e}"


def move_file(src: str, dst: str) -> str:
    """Move or rename a file/folder."""
    try:
        s = Path(src).expanduser().resolve()
        d = Path(dst).expanduser().resolve()
        shutil.move(str(s), str(d))
        return f"✅ Moved: {s} → {d}"
    except Exception as e:
        return f"Error: {e}"


def copy_file(src: str, dst: str) -> str:
    """Copy a file or folder."""
    try:
        s = Path(src).expanduser().resolve()
        d = Path(dst).expanduser().resolve()
        if s.is_dir():
            shutil.copytree(str(s), str(d))
        else:
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(s), str(d))
        return f"✅ Copied: {s} → {d}"
    except Exception as e:
        return f"Error: {e}"


def delete_file(path: str) -> str:
    """Delete a file or empty folder."""
    try:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            return f"Not found: {p}"
        if p.is_dir():
            if any(p.iterdir()):
                return f"⚠ Folder not empty: {p} — use shell 'rm -r' if you're sure"
            p.rmdir()
        else:
            p.unlink()
        return f"✅ Deleted: {p}"
    except Exception as e:
        return f"Error: {e}"


def search_files(root: str = "~", pattern: str = "*", max_results: int = 50) -> str:
    """Search for files by glob pattern."""
    try:
        p = Path(root).expanduser().resolve()
        results = []
        for match in p.rglob(pattern):
            if len(results) >= max_results:
                break
            # Skip hidden and system dirs
            parts = match.parts
            if any(part.startswith(".") for part in parts):
                continue
            if any(skip in parts for skip in ("__pycache__", "node_modules", ".git")):
                continue
            try:
                sz = match.stat().st_size
                results.append(f"  {match}  ({sz:,} bytes)")
            except Exception:
                results.append(f"  {match}")
        if results:
            return f"🔍 Found {len(results)} match(es):\n" + "\n".join(results)
        return f"🔍 No matches for '{pattern}' in {p}"
    except Exception as e:
        return f"Error: {e}"


def open_thing(target: str) -> str:
    """Open an application, folder, file, or URL."""
    system = platform.system()
    target = target.strip()

    # Resolve common folder names
    folder_aliases = {
        "pictures": os.path.expanduser("~/Pictures"),
        "photos": os.path.expanduser("~/Pictures"),
        "documents": os.path.expanduser("~/Documents"),
        "downloads": os.path.expanduser("~/Downloads"),
        "desktop": os.path.expanduser("~/Desktop"),
        "music": os.path.expanduser("~/Music"),
        "videos": os.path.expanduser("~/Videos"),
        "home": os.path.expanduser("~"),
        "my pictures": os.path.expanduser("~/Pictures"),
        "my documents": os.path.expanduser("~/Documents"),
        "my downloads": os.path.expanduser("~/Downloads"),
        "my photos": os.path.expanduser("~/Pictures"),
        "my music": os.path.expanduser("~/Music"),
        "my videos": os.path.expanduser("~/Videos"),
    }

    resolved = folder_aliases.get(target.lower(), target)

    # If it's a path that exists, open it with the system file manager
    path = Path(resolved).expanduser()
    if path.exists():
        try:
            if system == "Linux":
                subprocess.Popen(["xdg-open", str(path)],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
            elif system == "Darwin":
                subprocess.Popen(["open", str(path)])
            elif system == "Windows":
                os.startfile(str(path))
            return f"✅ Opened: {path}"
        except Exception as e:
            return f"Error opening {path}: {e}"

    # Otherwise try as an application name
    try:
        if system == "Linux":
            subprocess.Popen(
                [target], stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, start_new_session=True)
        elif system == "Darwin":
            subprocess.Popen(["open", "-a", target])
        elif system == "Windows":
            os.startfile(target)
        else:
            return f"Unsupported OS: {system}"
        return f"✅ Opened: {target}"
    except Exception as e:
        return f"Could not open '{target}': {e}"


def system_info() -> str:
    """Quick system snapshot."""
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=0.5)
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        return (
            f"CPU: {cpu}%\n"
            f"RAM: {ram.used / (1024**3):.1f} / {ram.total / (1024**3):.1f} GB ({ram.percent}%)\n"
            f"Disk: {disk.used / (1024**3):.1f} / {disk.total / (1024**3):.1f} GB ({disk.percent}%)\n"
            f"Platform: {platform.system()} {platform.release()}"
        )
    except ImportError:
        return f"Platform: {platform.system()} {platform.release()}\n(install psutil for full stats)"


def get_processes(n: int = 20) -> str:
    """List top processes by CPU usage."""
    try:
        import psutil
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
            try:
                info = p.info
                procs.append(info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        procs.sort(key=lambda x: x.get("cpu_percent", 0), reverse=True)
        lines = [f"{'PID':>7}  {'CPU%':>5}  {'MEM%':>5}  NAME"]
        for p in procs[:n]:
            lines.append(
                f"{p.get('pid', '?'):>7}  "
                f"{p.get('cpu_percent', 0):>5.1f}  "
                f"{p.get('memory_percent', 0):>5.1f}  "
                f"{p.get('name', '?')}"
            )
        return "\n".join(lines)
    except ImportError:
        return "psutil not installed — cannot list processes"


def kill_process(pid: int) -> str:
    """Kill a process by PID."""
    try:
        import psutil
        proc = psutil.Process(pid)
        name = proc.name()
        proc.terminate()
        return f"✅ Terminated: {name} (PID {pid})"
    except Exception as e:
        return f"Error: {e}"


# ── Mouse, keyboard, and screen control ──────────────────────

try:
    import pyautogui
    pyautogui.FAILSAFE = True   # move mouse to top-left corner to abort
    pyautogui.PAUSE = 0.15
    PYAUTOGUI_OK = True
except ImportError:
    PYAUTOGUI_OK = False


def _need_gui():
    if not PYAUTOGUI_OK:
        return (
            "❌ pyautogui not installed.\n"
            "Run: pip install pyautogui\n"
            "On Linux also: sudo apt install python3-tk python3-dev scrot"
        )
    return None


def mouse_click(args: str = "") -> str:
    """Click at coordinates or current pos. Usage: click [x y] [left|right|middle]"""
    err = _need_gui()
    if err:
        return err
    parts = args.split()
    try:
        if len(parts) >= 2 and parts[0].isdigit():
            x, y = int(parts[0]), int(parts[1])
            btn = parts[2] if len(parts) > 2 else "left"
            pyautogui.click(x, y, button=btn)
            return f"✅ Clicked ({x}, {y}) [{btn}]"
        else:
            btn = parts[0] if parts else "left"
            pos = pyautogui.position()
            pyautogui.click(button=btn)
            return f"✅ Clicked at ({pos.x}, {pos.y}) [{btn}]"
    except Exception as e:
        return f"Click error: {e}"


def mouse_doubleclick(args: str = "") -> str:
    """Double-click. Usage: doubleclick [x y]"""
    err = _need_gui()
    if err:
        return err
    parts = args.split()
    try:
        if len(parts) >= 2 and parts[0].isdigit():
            pyautogui.doubleClick(int(parts[0]), int(parts[1]))
            return f"✅ Double-clicked ({parts[0]}, {parts[1]})"
        else:
            pos = pyautogui.position()
            pyautogui.doubleClick()
            return f"✅ Double-clicked at ({pos.x}, {pos.y})"
    except Exception as e:
        return f"Error: {e}"


def mouse_move(args: str = "") -> str:
    """Move mouse. Usage: moveto x y"""
    err = _need_gui()
    if err:
        return err
    parts = args.split()
    try:
        if len(parts) >= 2:
            x, y = int(parts[0]), int(parts[1])
            pyautogui.moveTo(x, y, duration=0.3)
            return f"✅ Moved to ({x}, {y})"
        else:
            pos = pyautogui.position()
            return f"Mouse is at ({pos.x}, {pos.y})"
    except Exception as e:
        return f"Error: {e}"


def mouse_scroll(args: str = "") -> str:
    """Scroll up or down. Usage: scroll [amount] (positive=up, negative=down)"""
    err = _need_gui()
    if err:
        return err
    try:
        amount = int(args.strip()) if args.strip() else -3
        pyautogui.scroll(amount)
        direction = "up" if amount > 0 else "down"
        return f"✅ Scrolled {direction} ({abs(amount)} clicks)"
    except Exception as e:
        return f"Error: {e}"


def mouse_drag(args: str = "") -> str:
    """Drag from current position. Usage: drag x y [duration]"""
    err = _need_gui()
    if err:
        return err
    parts = args.split()
    try:
        if len(parts) >= 2:
            x, y = int(parts[0]), int(parts[1])
            dur = float(parts[2]) if len(parts) > 2 else 0.5
            start = pyautogui.position()
            pyautogui.drag(x, y, duration=dur)
            return f"✅ Dragged from ({start.x},{start.y}) by ({x},{y})"
        return "Usage: drag x_offset y_offset [duration]"
    except Exception as e:
        return f"Error: {e}"


def keyboard_type(text: str = "") -> str:
    """Type text with the keyboard. Usage: type your text here"""
    err = _need_gui()
    if err:
        return err
    if not text.strip():
        return "Usage: type your text here"
    try:
        pyautogui.typewrite(text, interval=0.03) if text.isascii() else pyautogui.write(text)
        return f"✅ Typed: {text[:80]}{'...' if len(text) > 80 else ''}"
    except Exception as e:
        return f"Error: {e}"


def keyboard_hotkey(args: str = "") -> str:
    """Press a key combo. Usage: hotkey ctrl c / hotkey alt f4 / hotkey enter"""
    err = _need_gui()
    if err:
        return err
    if not args.strip():
        return "Usage: hotkey ctrl c / hotkey alt tab / hotkey enter"
    keys = [k.strip() for k in args.replace("+", " ").split()]
    try:
        pyautogui.hotkey(*keys)
        return f"✅ Pressed: {' + '.join(keys)}"
    except Exception as e:
        return f"Error: {e}"


def keyboard_press(args: str = "") -> str:
    """Press a single key. Usage: press enter / press tab / press escape"""
    err = _need_gui()
    if err:
        return err
    key = args.strip().lower()
    if not key:
        return "Usage: press enter / press tab / press escape / press f5"
    try:
        pyautogui.press(key)
        return f"✅ Pressed: {key}"
    except Exception as e:
        return f"Error: {e}"


def take_screenshot(args: str = "") -> str:
    """Take a screenshot. Usage: screenshot [filename]"""
    err = _need_gui()
    if err:
        return err
    import time as _time
    fname = args.strip() if args.strip() else f"screenshot_{_time.strftime('%Y%m%d_%H%M%S')}.png"
    if not fname.endswith(".png"):
        fname += ".png"
    save_path = Path.home() / "Pictures" / fname
    try:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        img = pyautogui.screenshot()
        img.save(str(save_path))
        return f"✅ Screenshot saved: {save_path}"
    except Exception as e:
        return f"Error: {e}"


def get_mouse_pos(args: str = "") -> str:
    """Get current mouse position."""
    err = _need_gui()
    if err:
        return err
    pos = pyautogui.position()
    screen = pyautogui.size()
    return f"Mouse: ({pos.x}, {pos.y})  Screen: {screen.width}x{screen.height}"


def get_screen_size(args: str = "") -> str:
    """Get screen resolution."""
    err = _need_gui()
    if err:
        return err
    s = pyautogui.size()
    return f"Screen: {s.width} x {s.height}"


def find_on_screen(args: str = "") -> str:
    """Find text or image on screen. Usage: locatetext some text"""
    err = _need_gui()
    if err:
        return err
    if not args.strip():
        return "Usage: locate <image_path.png>"
    # Image-based locate
    try:
        loc = pyautogui.locateOnScreen(args.strip(), confidence=0.8)
        if loc:
            center = pyautogui.center(loc)
            return f"✅ Found at ({center.x}, {center.y}) — region: {loc}"
        return f"❌ Not found on screen: {args.strip()}"
    except Exception as e:
        return f"Error: {e}"


# ── Built-in action registry ────────────────────────────────

BUILTIN_ACTIONS = {
    # File operations
    "ls":          ("List files", list_files),
    "cat":         ("Read file", read_file),
    "write":       ("Write file", write_file),
    "mv":          ("Move/rename", move_file),
    "cp":          ("Copy", copy_file),
    "rm":          ("Delete", delete_file),
    "find":        ("Search files", search_files),
    "open":        ("Open file/folder/app", open_thing),
    # System
    "sysinfo":     ("System info", system_info),
    "ps":          ("List processes", get_processes),
    "kill":        ("Kill process", kill_process),
    # Mouse
    "click":       ("Mouse click", mouse_click),
    "doubleclick": ("Double click", mouse_doubleclick),
    "moveto":      ("Move mouse", mouse_move),
    "scroll":      ("Scroll", mouse_scroll),
    "drag":        ("Drag mouse", mouse_drag),
    "mousepos":    ("Get mouse position", get_mouse_pos),
    # Keyboard
    "type":        ("Type text", keyboard_type),
    "hotkey":      ("Key combo", keyboard_hotkey),
    "press":       ("Press key", keyboard_press),
    # Screen
    "screenshot":  ("Take screenshot", take_screenshot),
    "screensize":  ("Screen resolution", get_screen_size),
    "locate":      ("Find on screen", find_on_screen),
}


# ── Shell command execution ──────────────────────────────────

def run_command(
    command:   str,
    on_result: Callable[[str], None],
    on_error:  Callable[[str], None],
    timeout:   int = 60,
) -> None:
    """Execute a shell command in a background thread."""

    def _run():
        if _mode == MODE_OFF:
            on_error(
                "🖱️ Agent Mode is OFF.\n\n"
                "Toggle it on in the top bar to allow command execution.\n"
                "Modes: Supervised (asks before running) or Full Control."
            )
            return

        allowed, reason, needs_confirm = check_command(command)
        if not allowed:
            on_error(f"⛔ {reason}")
            return

        try:
            args = shlex.split(command)
            result = subprocess.run(
                args,
                shell=False,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=os.path.expanduser("~"),
            )
            stdout = result.stdout.strip()
            stderr = result.stderr.strip()
            output = stdout or stderr or "(no output)"

            # Truncate very long output
            if len(output) > 8000:
                output = output[:8000] + f"\n\n... ({len(output) - 8000} chars truncated)"

            on_result(
                f"```\n$ {command}\n{output}\n```\n"
                f"Exit code: {result.returncode}"
            )
            logger.info(f"Agent command: {command} → exit {result.returncode}")

        except subprocess.TimeoutExpired:
            on_error(f"Command timed out after {timeout}s")
        except Exception as e:
            on_error(f"Command failed: {e}")

    threading.Thread(target=_run, daemon=True).start()


# ── Module entry point ───────────────────────────────────────


# ── Module entry point ───────────────────────────────────────

def handle(
    message:   str,
    on_result: Callable[[str], None],
    on_error:  Callable[[str], None],
) -> None:
    """Entry point — parses natural language and slash commands."""
    if _mode == MODE_OFF:
        on_error(
            "🖱️ Agent Mode is OFF.\n\n"
            "Click the Agent toggle in the top bar to enable it.\n"
            "• Supervised — runs commands, confirms dangerous ones\n"
            "• Full Control — unrestricted (click toggle twice)"
        )
        return

    command = message
    for prefix in ["/run ", "/exec ", "/agent ", "/do "]:
        if message.lower().startswith(prefix):
            command = message[len(prefix):].strip()
            break

    if not command:
        on_error("Please provide a command to run.")
        return

    msg_lower = command.lower().strip()

    # ── Natural language: open things ────────────────────────

    for pattern in ["open my ", "open the ", "open "]:
        if msg_lower.startswith(pattern):
            target = command[len(pattern):].strip()
            for noise in [" folder", " directory", " app", " application",
                          " program", " please", " for me"]:
                if target.lower().endswith(noise):
                    target = target[:len(target) - len(noise)].strip()
            on_result(f"```\n{open_thing(target)}\n```")
            return

    # "go to pictures" / "navigate to downloads" / "cd ~"
    for trigger in ["go to ", "navigate to ", "cd "]:
        if msg_lower.startswith(trigger):
            target = command[len(trigger):].strip()
            for noise in [" folder", " directory"]:
                if target.lower().endswith(noise):
                    target = target[:len(target) - len(noise)].strip()
            on_result(f"```\n{open_thing(target)}\n```")
            return

    # ── Natural language: list/show files ────────────────────

    for pattern in ["list my files", "show my files", "show me my files",
                    "list files", "show files"]:
        if msg_lower.startswith(pattern):
            rest = command[len(pattern):].strip()
            on_result(f"```\n{list_files(rest if rest else '~')}\n```")
            return

    for pattern in ["what's in ", "whats in ", "what is in ",
                    "show me what's in ", "show me "]:
        if msg_lower.startswith(pattern):
            target = command[len(pattern):].strip()
            for noise in [" folder", " directory"]:
                if target.lower().endswith(noise):
                    target = target[:len(target) - len(noise)].strip()
            aliases = {"my pictures": "~/Pictures", "my documents": "~/Documents",
                       "my downloads": "~/Downloads", "my desktop": "~/Desktop",
                       "my home": "~", "my music": "~/Music", "my videos": "~/Videos"}
            target = aliases.get(target.lower(), target)
            on_result(f"```\n{list_files(target)}\n```")
            return

    # ── Natural language: get/grab/fetch files ───────────────

    m = re.search(
        r'(?:get|grab|fetch)\s+(?:me\s+)?(?:the\s+)?(.+?)'
        r'(?:\s+(?:from|under|in|inside)\s+(.+))?$',
        msg_lower
    )
    if m and any(w in msg_lower for w in ["get ", "grab ", "fetch "]):
        target = m.group(1).strip()
        location = m.group(2).strip() if m.group(2) else ""
        aliases = {"pictures": "~/Pictures", "photos": "~/Pictures",
                   "documents": "~/Documents", "downloads": "~/Downloads",
                   "desktop": "~/Desktop", "home": "~",
                   "my pictures": "~/Pictures", "my documents": "~/Documents"}
        base = aliases.get(location.lower(), location) if location else "~"
        search_path = str(Path(base).expanduser())
        on_result(f"```\n{search_files(search_path, f'*{target}*', 20)}\n```")
        return

    # ── Natural language: create folder ──────────────────────

    for pattern in ["create a folder ", "create folder ", "make folder ",
                    "create a directory ", "create directory ", "mkdir "]:
        if msg_lower.startswith(pattern):
            path = command[len(pattern):].strip()
            try:
                p = Path(path).expanduser().resolve()
                p.mkdir(parents=True, exist_ok=True)
                on_result(f"```\n✅ Created: {p}\n```")
            except Exception as e:
                on_error(f"Error: {e}")
            return

    # ── Natural language: system info ────────────────────────

    if any(msg_lower.startswith(p) for p in
           ["system info", "system status", "system health",
            "how much ram", "how much memory", "how much disk",
            "how much storage", "how much cpu"]):
        on_result(f"```\n{system_info()}\n```")
        return

    # ── Natural language: mouse ──────────────────────────────

    if msg_lower.startswith("click ") or msg_lower == "click":
        args = command[6:].strip() if len(command) > 6 else ""
        for noise in ["on the ", "on ", "at ", "the "]:
            if args.lower().startswith(noise):
                args = args[len(noise):]
        on_result(f"```\n{mouse_click(args)}\n```")
        return

    if "double" in msg_lower and "click" in msg_lower:
        rest = re.sub(r'.*double\s*click\s*', '', command, flags=re.I).strip()
        for noise in ["on the ", "on ", "at "]:
            if rest.lower().startswith(noise):
                rest = rest[len(noise):]
        on_result(f"```\n{mouse_doubleclick(rest)}\n```")
        return

    if "scroll up" in msg_lower:
        on_result(f"```\n{mouse_scroll('5')}\n```")
        return
    if "scroll down" in msg_lower:
        on_result(f"```\n{mouse_scroll('-5')}\n```")
        return
    if msg_lower.startswith("scroll "):
        on_result(f"```\n{mouse_scroll(command[7:].strip())}\n```")
        return

    if ("move" in msg_lower and "mouse" in msg_lower):
        m = re.search(r'(\d+)\s+(\d+)', command)
        if m:
            on_result(f"```\n{mouse_move(f'{m.group(1)} {m.group(2)}')}\n```")
        else:
            on_result(f"```\n{get_mouse_pos()}\n```")
        return

    if "where" in msg_lower and "mouse" in msg_lower:
        on_result(f"```\n{get_mouse_pos()}\n```")
        return

    # ── Natural language: keyboard ───────────────────────────

    if msg_lower.startswith("type "):
        on_result(f"```\n{keyboard_type(command[5:].strip())}\n```")
        return

    for prefix in ["press ", "hit ", "tap "]:
        if msg_lower.startswith(prefix):
            key = command[len(prefix):].strip()
            for noise in ["the ", "key ", "button "]:
                if key.lower().startswith(noise):
                    key = key[len(noise):]
            on_result(f"```\n{keyboard_press(key)}\n```")
            return

    # "ctrl+c" / "alt tab" / hotkeys
    hotkey_match = re.match(r'(ctrl|alt|shift|super|win|cmd)[\s+]+(.*)', msg_lower)
    if hotkey_match:
        keys = command.replace("+", " ").split()
        on_result(f"```\n{keyboard_hotkey(' '.join(keys))}\n```")
        return

    # ── Natural language: screenshot ─────────────────────────

    if "screenshot" in msg_lower:
        rest = re.sub(r'.*screenshot\s*', '', command, flags=re.I).strip()
        on_result(f"```\n{take_screenshot(rest)}\n```")
        return

    if "screen size" in msg_lower or "resolution" in msg_lower:
        on_result(f"```\n{get_screen_size()}\n```")
        return

    # ── Natural language: install ────────────────────────────

    if msg_lower.startswith("install "):
        pkg = command[8:].strip()
        for noise in [" for me", " please", " on my computer"]:
            if pkg.lower().endswith(noise.strip()):
                pkg = pkg[:len(pkg) - len(noise.strip())].strip()
        sys_name = platform.system()
        if sys_name == "Linux":
            cmd = f"sudo apt install -y {pkg}"
        elif sys_name == "Darwin":
            cmd = f"brew install {pkg}"
        elif sys_name == "Windows":
            cmd = f"winget install {pkg}"
        else:
            on_error(f"Don't know how to install on {sys_name}")
            return
        on_result(f"```\n🔧 Running: {cmd}\n```")
        run_command(cmd, on_result, on_error, timeout=300)
        return

    # ── Slash command / built-in action lookup ───────────────

    command_clean = command.lstrip("/")
    cmd_parts = command_clean.split(None, 1)
    action_name = cmd_parts[0].lower()
    if action_name in BUILTIN_ACTIONS:
        _desc, func = BUILTIN_ACTIONS[action_name]
        args_str = cmd_parts[1] if len(cmd_parts) > 1 else ""
        try:
            if action_name == "write" and " " in args_str:
                path, content = args_str.split(None, 1)
                result = func(path, content)
            elif action_name in ("mv", "cp") and " " in args_str:
                src, dst = args_str.rsplit(None, 1)
                result = func(src, dst)
            elif action_name == "kill":
                result = func(int(args_str))
            elif args_str:
                result = func(args_str)
            else:
                result = func()
            on_result(f"```\n{result}\n```")
        except Exception as e:
            on_error(f"Action '{action_name}' failed: {e}")
        return

    # ── Smart Agent: use loaded model to plan complex requests ──
    if is_enabled() and _try_smart_plan(command, on_result, on_error):
        return

    # ── Fallback: run as shell command ───────────────────────
    run_command(command, on_result, on_error)


# ── Smart Agent Planner ──────────────────────────────────────

PLANNER_SYSTEM = """You are an action planner for a desktop AI assistant running on Linux.
The user wants something done on their computer. Parse their request
into a JSON array of steps. Each step is an object with "action" and "args".

Available actions:
FILES:
- ls: args = "path" (list directory contents)
- cat: args = "path" (read a file)
- write: args = {"path": "...", "content": "..."}
- mv: args = {"src": "...", "dst": "..."}
- cp: args = {"src": "...", "dst": "..."}
- rm: args = "path"
- find: args = {"root": "...", "pattern": "*keyword*"}
- open: args = "path or app name" (opens with system default)

MOUSE & KEYBOARD:
- click: args = "x y" or "" (click at coords or current pos)
- doubleclick: args = "x y" or ""
- type: args = "text to type on keyboard"
- press: args = "enter" / "tab" / "escape" / "f5" etc.
- hotkey: args = "ctrl c" / "alt tab" / "ctrl shift t" etc.
- scroll: args = "5" (positive=up, negative=down)

SCREEN:
- screenshot: args = "filename" or ""

SYSTEM:
- sysinfo: args = ""
- ps: args = "" (list processes)
- kill: args = "pid"
- shell: args = "any bash command"
- browse: args = "url" (open URL in default browser)
- wait: args = "seconds" (pause between steps)
- say: args = "message to display to user"

Path aliases: ~ = home dir, ~/Pictures, ~/Documents, ~/Downloads, ~/Desktop

Use {RESULT} in args to reference the output of the previous step.

Respond with ONLY a valid JSON array. No markdown, no explanation.

Examples:

User: "find my vacation photos and copy them to desktop"
[{"action":"find","args":{"root":"~/Pictures","pattern":"*vacation*"}},{"action":"say","args":"Found matching files, copying to Desktop..."},{"action":"shell","args":"cp -r ~/Pictures/*vacation* ~/Desktop/"}]

User: "open firefox and go to youtube"
[{"action":"open","args":"firefox"},{"action":"wait","args":"3"},{"action":"hotkey","args":"ctrl l"},{"action":"type","args":"youtube.com"},{"action":"press","args":"enter"}]

User: "what's eating my CPU"
[{"action":"ps","args":""},{"action":"say","args":"Here are your top processes."}]

User: "take a screenshot and save it"
[{"action":"screenshot","args":""},{"action":"say","args":"Screenshot saved to ~/Pictures/"}]

User: "clean up my downloads folder - delete all .tmp files"
[{"action":"find","args":{"root":"~/Downloads","pattern":"*.tmp"}},{"action":"say","args":"Found temp files. Deleting..."},{"action":"shell","args":"find ~/Downloads -name '*.tmp' -delete"},{"action":"say","args":"Done! Temp files cleaned."}]

ONLY output the JSON array."""


def _try_smart_plan(
    message:   str,
    on_result: Callable[[str], None],
    on_error:  Callable[[str], None],
) -> bool:
    """
    Use the loaded model to parse a complex request into actions.
    Returns True if it handled the message, False to fall through.
    """
    from core.model_manager import generate_sync, is_model_loaded

    if not is_model_loaded():
        return False

    on_result("🧠 Thinking about your request...")

    # Ask the model to plan
    response = generate_sync(
        prompt=message,
        system=PLANNER_SYSTEM,
        max_tokens=512,
        temperature=0.2,
    )

    if not response:
        return False

    # Parse JSON action plan
    plan = _parse_plan(response)
    if not plan:
        return False

    # Execute the plan
    on_result(f"\n🧠 **Smart Agent Plan** — {len(plan)} steps:\n")

    last_result = ""
    for i, step in enumerate(plan):
        action = step.get("action", "")
        args   = step.get("args", "")

        # Result chaining — replace {RESULT} with previous step output
        if isinstance(args, str) and "{RESULT}" in args:
            args = args.replace("{RESULT}", last_result[:500])
        elif isinstance(args, dict):
            for k, v in args.items():
                if isinstance(v, str) and "{RESULT}" in v:
                    args[k] = v.replace("{RESULT}", last_result[:500])

        on_result(f"\n**Step {i+1}:** `{action}` → {_summarize_args(args)}")

        try:
            result = _execute_step(action, args)
            if result:
                last_result = result
                on_result(f"\n```\n{result}\n```")
        except Exception as e:
            on_result(f"\n❌ Step {i+1} failed: {e}")
            break

    on_result("\n\n✅ **Plan complete.**")
    return True


def _parse_plan(response: str) -> list:
    """Extract JSON action array from model response."""
    import json as _json

    # Try direct parse
    text = response.strip()

    # Strip markdown fences if present
    if text.startswith("```"):
        text = text.split("\n", 1)[-1]
    if text.endswith("```"):
        text = text.rsplit("```", 1)[0]
    text = text.strip()

    # Find the JSON array
    start = text.find("[")
    end   = text.rfind("]")
    if start == -1 or end == -1:
        return []

    try:
        plan = _json.loads(text[start:end + 1])
        if isinstance(plan, list) and all(isinstance(s, dict) for s in plan):
            return plan
    except _json.JSONDecodeError:
        pass

    return []


def _summarize_args(args) -> str:
    """Make args human-readable for progress display."""
    if isinstance(args, dict):
        return ", ".join(f"{k}={v}" for k, v in args.items())
    if isinstance(args, str) and len(args) > 60:
        return args[:60] + "..."
    return str(args) if args else "(none)"


def _execute_step(action: str, args) -> str:
    """Execute a single action step. Returns result string."""
    import time as _time
    action = action.lower().strip()

    # "say" — display message to user
    if action == "say":
        return str(args) if args else ""

    # "wait" — pause between steps
    if action == "wait":
        try:
            secs = float(args) if args else 1
            secs = min(secs, 30)  # cap at 30 seconds
            _time.sleep(secs)
            return f"Waited {secs}s"
        except (ValueError, TypeError):
            _time.sleep(1)
            return "Waited 1s"

    # "browse" — open URL in default browser
    if action == "browse":
        import webbrowser
        url = str(args).strip()
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        try:
            webbrowser.open(url)
            return f"✅ Opened: {url}"
        except Exception as e:
            return f"Error: {e}"

    # Built-in actions
    if action in BUILTIN_ACTIONS:
        _desc, func = BUILTIN_ACTIONS[action]

        if isinstance(args, dict):
            # Multi-arg actions
            if action == "write":
                return func(args.get("path", ""), args.get("content", ""))
            elif action in ("mv", "cp"):
                return func(args.get("src", ""), args.get("dst", ""))
            elif action == "find":
                return search_files(
                    args.get("root", "~"),
                    args.get("pattern", "*"),
                    20
                )
            else:
                # Pass as string
                return func(str(args))
        elif isinstance(args, str):
            if action == "kill":
                try:
                    return func(int(args))
                except ValueError:
                    return f"Invalid PID: {args}"
            elif args:
                return func(args)
            else:
                return func()
        else:
            return func()

    # "shell" action — run arbitrary command
    if action == "shell":
        cmd = str(args) if args else ""
        if not cmd:
            return "No command provided"

        allowed, reason, _ = check_command(cmd)
        if not allowed:
            return f"⛔ Blocked: {reason}"

        try:
            result = subprocess.run(
                shlex.split(cmd),
                capture_output=True, text=True,
                timeout=60,
                cwd=os.path.expanduser("~"),
            )
            output = result.stdout.strip() or result.stderr.strip() or "(done)"
            if len(output) > 2000:
                output = output[:2000] + "..."
            return output
        except subprocess.TimeoutExpired:
            return "Command timed out"
        except Exception as e:
            return f"Error: {e}"

    return f"Unknown action: {action}"
