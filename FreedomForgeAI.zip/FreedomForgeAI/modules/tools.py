# ============================================================
#  FreedomForge AI — modules/tools.py
#  Tool repository for agent and module system
# ============================================================

from typing import Callable, Optional


class ToolRepo:
    """Registry of callable tools available to the agent system."""

    def __init__(self):
        self.tools: dict = {}

    def add_tool(self, name: str, tool: Callable) -> None:
        self.tools[name] = tool

    def get_tool(self, name: str) -> Optional[Callable]:
        return self.tools.get(name, None)

    def list_tools(self) -> list:
        return list(self.tools.keys())

    def remove_tool(self, name: str) -> bool:
        return self.tools.pop(name, None) is not None


# Global instance
_repo = ToolRepo()


def get_repo() -> ToolRepo:
    return _repo
