# ============================================================
#  FreedomForge AI — modules/__init__.py
#  Module registry and message router
# ============================================================

import re
from typing import Optional, Callable

# Module trigger patterns
_TRIGGERS = {
    "video": [
        r"\bmake\s+(a\s+)?video\b",
        r"\bgenerate\s+(a\s+)?video\b",
        r"\bcreate\s+(a\s+)?video\b",
        r"\bvideo\s+of\b",
        r"^/video\b",
    ],
    "image": [
        r"\bmake\s+(a[n]?\s+)?image\b",
        r"\bgenerate\s+(a[n]?\s+)?image\b",
        r"\bdraw\b",
        r"\bpaint\b",
        r"^/image\b",
    ],
    "agent": [
        r"^/run\b",
        r"^/exec\b",
        r"^/agent\b",
        r"^/do\b",
        r"^/ls\b",
        r"^/ps\b",
        r"^/sysinfo\b",
        r"\brun\s+this\s+command\b",
        r"\bexecute\s+on\s+my\s+computer\b",
        r"\bopen\s+(the\s+)?(app|folder|file|directory|program|terminal|browser)\b",
        r"\bopen\s+my\s+\w+",
        r"^open\s+\w+",
        r"\blist\s+(my\s+)?files\b",
        r"\bshow\s+(me\s+)?(my\s+)?files\b",
        r"\bwhat.s\s+(in|inside)\s+(my|the|this)\b",
        r"\bwhat\s+is\s+(in|inside)\s+(my|the|this)\b",
        r"\bkill\s+(the\s+)?process\b",
        r"\bcreate\s+(a\s+)?(file|folder|directory)\b",
        r"\bdelete\s+(the\s+)?(file|folder)\b",
        r"\bmove\s+(the\s+)?(file|folder)\b",
        r"\bcopy\s+(the\s+)?(file|folder)\b",
        r"\brename\s+(the\s+)?(file|folder)\b",
        r"\bsystem\s+(info|status|health)\b",
        r"\bhow\s+much\s+(ram|memory|disk|storage|cpu)\b",
        r"\binstall\s+\w+",
        r"\buninstall\s+\w+",
        r"\bclick\s+(on|at|the)\b",
        r"\bdouble\s*click\b",
        r"\bscroll\s+(up|down)\b",
        r"\btype\s+.{3,}",
        r"\bpress\s+(enter|tab|escape|esc|space|backspace|delete|f\d+)\b",
        r"\btake\s+(a\s+)?screenshot\b",
        r"\bscreenshot\b",
        r"\bwhere.s\s+(my\s+)?mouse\b",
        r"\bwhere\s+is\s+(my\s+)?mouse\b",
        r"\bwhere\s+is\s+(my\s+)?mouse\b",
        r"\bmove\s+(the\s+)?mouse\b",
        r"^/click\b",
        r"^/type\b",
        r"^/press\b",
        r"^/hotkey\b",
        r"^/screenshot\b",
        r"^/moveto\b",
        r"^/scroll\b",
        r"^/mousepos\b",
        r"^/screensize\b",
        r"^/locate\b",
        r"\binstall\s+\w+",
        r"\bgo\s+to\s+(my\s+)?\w+",
        r"\bnavigate\s+to\b",
        r"\bget\s+me\s+(the\s+)?",
        r"\bgrab\s+(me\s+)?(the\s+)?",
    ],
}

_registry: dict = {}


def register(name: str, module) -> None:
    _registry[name] = module


def get(name: str):
    return _registry.get(name)


def route(message: str) -> Optional[str]:
    """
    Check if a message should be routed to a module.
    Returns module name string or None if regular chat.
    """
    msg_lower = message.lower()
    for module_name, patterns in _TRIGGERS.items():
        for pattern in patterns:
            if re.search(pattern, msg_lower):
                return module_name
    return None


def handle(
    module_name: str,
    message: str,
    on_result: Callable[[str], None],
    on_error:  Callable[[str], None],
) -> bool:
    """
    Route a message to the appropriate module.
    Returns True if handled, False if module not available.
    """
    module = _registry.get(module_name)
    if module is None:
        on_error(
            f"The {module_name} module is not available yet. "
            f"It's coming in a future update!"
        )
        return False
    try:
        module.handle(message, on_result, on_error)
        return True
    except Exception as e:
        on_error(f"Module error: {e}")
        return False
