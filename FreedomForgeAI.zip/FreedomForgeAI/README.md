# ⚒️ FreedomForge AI

**Free. Local. Private. For Everyone.**

A privacy-first local AI desktop assistant that runs entirely on your machine. No cloud, no account, no subscription. Built with Python and CustomTkinter.

*Dedicated to Miranda. She will never be forgotten.*

---

## Features

- **100% Local Inference** — runs GGUF models via llama.cpp on your hardware
- **Model Library** — curated list of 20+ models from TinyLlama to Llama 3.1 70B, plus HuggingFace search
- **My Models** — scan your computer for existing .gguf files and manage loaded models
- **Privacy Dashboard** — encryption status, network kill switch, VPN detection, connection monitor
- **Network Kill Switch** — instantly block all internet traffic with one toggle
- **System Monitor** — real-time CPU/GPU/RAM stats, disk health, startup program management
- **Training Center** — practice loops and idle training for your models
- **Video Generation** — ComfyUI integration with LTX-Video (auto-installer)
- **Plugin System** — drop Python files into `plugins/` to extend functionality
- **Agent Mode** — let the AI execute shell commands (with safety guardrails)
- **Voice I/O** — speech recognition input + text-to-speech output
- **Encrypted Storage** — Fernet encryption with PBKDF2 key derivation
- **Crash Reporter** — local crash logs with optional anonymous reporting
- **15 Languages** — full UI internationalization
- **6 Themes** — Midnight, Forge, Aurora, Terminal, Sakura, Light
- **Cross-Platform** — Linux, macOS, Windows with platform-specific installers

## Quick Start

### Linux / macOS
```bash
bash install.sh
```

### Windows
Double-click `install.bat` or run:
```powershell
powershell -ExecutionPolicy Bypass -File install.ps1
```

### Manual
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 main.py
```

## Requirements

- Python 3.10+
- 4 GB RAM minimum (8+ GB recommended)
- GPU optional but recommended (NVIDIA CUDA or Apple Metal)

## Privacy Note

FreedomForge AI runs entirely offline. The only network calls are:

- **Model downloads** — user-initiated from HuggingFace
- **Update checks** — GitHub API, optional
- **Crash reports** — opt-in, anonymous, no personal data
- **Voice input** — currently uses Google Speech API (opt-in toggle; local Whisper replacement planned)

The network kill switch can block ALL traffic instantly.

## Project Structure

```
FreedomForgeAI/
├── main.py              # Entry point
├── core/                # Backend — config, encryption, model manager, privacy, etc.
├── ui/                  # CustomTkinter interface panels
├── modules/             # Agent, video, ComfyUI client
├── plugins/             # Drop-in plugin system
├── assets/              # Themes and i18n strings
├── training/            # Training state and practice logs
├── utils/               # Paths, scroll fix, helpers
├── install.sh           # Linux/macOS installer
├── install.ps1          # Windows installer
└── requirements.txt     # Python dependencies
```

## License

AGPL-3.0 + Commons Clause

Copyright (c) 2026 Ryan Dennison

---

*Built by Ryan Dennison for his son and the world. Utilizing AI assistance.*
