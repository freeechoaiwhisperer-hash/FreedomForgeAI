# ============================================================
#  FreedomForge AI — ui/tamagotchi_tab.py
#  "Grow Your Own AI" — visual pet panel
# ============================================================

import customtkinter as ctk
from core import model_manager
from core.tamagotchi import get_pet, get_all_pets, STAGES


class TamagotchiPanel(ctk.CTkFrame):

    def __init__(self, master, app, theme: dict, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.app   = app
        self.theme = theme
        self._pet  = None
        self._tick_id = None
        self._build()

    def apply_theme(self, theme: dict):
        self.theme = theme
        for w in self.winfo_children():
            w.destroy()
        self._build()

    def _build(self):
        T = self.theme

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=10, pady=10)

        # Title
        ctk.CTkLabel(
            scroll, text="🥚  Grow Your Own AI",
            font=("Arial", 20, "bold"),
            text_color=T["gold"],
        ).pack(pady=(10, 2), anchor="w", padx=12)

        ctk.CTkLabel(
            scroll,
            text="Your AI is alive. Chat with it, train it, watch it evolve.",
            font=("Arial", 12),
            text_color=T["text_secondary"],
        ).pack(anchor="w", padx=12, pady=(0, 12))

        # ── Pet display card ─────────────────────────────────
        self._pet_card = ctk.CTkFrame(scroll, corner_radius=14, fg_color=T["bg_card"])
        self._pet_card.pack(fill="x", padx=12, pady=(0, 10))

        self._pet_inner = ctk.CTkFrame(self._pet_card, fg_color="transparent")
        self._pet_inner.pack(fill="x", padx=20, pady=20)

        self._refresh_pet()

        # ── Skills card ──────────────────────────────────────
        skills_card = ctk.CTkFrame(scroll, corner_radius=10, fg_color=T["bg_card"])
        skills_card.pack(fill="x", padx=12, pady=(0, 10))

        ctk.CTkLabel(
            skills_card, text="📊  Skills",
            font=("Arial", 14, "bold"),
            text_color=T["text_primary"],
        ).pack(anchor="w", padx=14, pady=(12, 6))

        self._skills_frame = ctk.CTkFrame(skills_card, fg_color="transparent")
        self._skills_frame.pack(fill="x", padx=14, pady=(0, 14))

        # ── Achievements card ────────────────────────────────
        ach_card = ctk.CTkFrame(scroll, corner_radius=10, fg_color=T["bg_card"])
        ach_card.pack(fill="x", padx=12, pady=(0, 10))

        ctk.CTkLabel(
            ach_card, text="🏆  Achievements",
            font=("Arial", 14, "bold"),
            text_color=T["text_primary"],
        ).pack(anchor="w", padx=14, pady=(12, 6))

        self._ach_frame = ctk.CTkFrame(ach_card, fg_color="transparent")
        self._ach_frame.pack(fill="x", padx=14, pady=(0, 14))

        # ── Evolution roadmap ────────────────────────────────
        evo_card = ctk.CTkFrame(scroll, corner_radius=10, fg_color=T["bg_card"])
        evo_card.pack(fill="x", padx=12, pady=(0, 10))

        ctk.CTkLabel(
            evo_card, text="🧬  Evolution Path",
            font=("Arial", 14, "bold"),
            text_color=T["text_primary"],
        ).pack(anchor="w", padx=14, pady=(12, 6))

        self._evo_frame = ctk.CTkFrame(evo_card, fg_color="transparent")
        self._evo_frame.pack(fill="x", padx=14, pady=(0, 14))

        self._refresh_details()
        self._start_tick()

    def _refresh_pet(self):
        T = self.theme
        for w in self._pet_inner.winfo_children():
            w.destroy()

        # Get current model's pet
        current = model_manager.get_current_model()
        if not current:
            ctk.CTkLabel(
                self._pet_inner,
                text="Load a model to meet your AI pet!",
                font=("Arial", 14),
                text_color=T["text_dim"],
            ).pack(pady=20)
            self._pet = None
            return

        self._pet = get_pet(current)
        self._pet.update_mood()
        pet   = self._pet
        stage = pet.get_stage()
        mood  = pet.get_mood_info()

        # Row 1: Big emoji + name + level
        top = ctk.CTkFrame(self._pet_inner, fg_color="transparent")
        top.pack(fill="x")

        ctk.CTkLabel(
            top, text=stage["emoji"],
            font=("Arial", 52),
        ).pack(side="left", padx=(0, 16))

        info = ctk.CTkFrame(top, fg_color="transparent")
        info.pack(side="left", fill="x", expand=True)

        # Name (editable)
        name_row = ctk.CTkFrame(info, fg_color="transparent")
        name_row.pack(anchor="w")

        self._name_lbl = ctk.CTkLabel(
            name_row,
            text=pet.get_display_name(),
            font=("Arial", 20, "bold"),
            text_color=T["text_primary"],
            cursor="hand2",
        )
        self._name_lbl.pack(side="left")
        self._name_lbl.bind("<Button-1>", self._rename)

        ctk.CTkLabel(
            name_row, text="  ✏️",
            font=("Arial", 12),
            text_color=T["text_dim"],
            cursor="hand2",
        ).pack(side="left")

        ctk.CTkLabel(
            info,
            text=f"Level {pet.level}  {stage['name']}  •  {pet.age_str()}",
            font=("Arial", 13),
            text_color=T["accent2"],
        ).pack(anchor="w")

        ctk.CTkLabel(
            info,
            text=stage["desc"],
            font=("Arial", 11, "italic"),
            text_color=T["text_secondary"],
        ).pack(anchor="w")

        # Mood display
        mood_row = ctk.CTkFrame(top, fg_color="transparent")
        mood_row.pack(side="right", padx=(10, 0))

        ctk.CTkLabel(
            mood_row, text=mood["emoji"],
            font=("Arial", 28),
        ).pack()

        ctk.CTkLabel(
            mood_row,
            text=mood["name"].capitalize(),
            font=("Arial", 11),
            text_color=T["text_secondary"],
        ).pack()

        # XP bar
        xp_frame = ctk.CTkFrame(self._pet_inner, fg_color="transparent")
        xp_frame.pack(fill="x", pady=(14, 0))

        ctk.CTkLabel(
            xp_frame,
            text=f"XP: {pet.xp:,}  •  {pet.xp_to_next():,} to next level",
            font=("Arial", 11),
            text_color=T["text_secondary"],
        ).pack(anchor="w")

        xp_bar = ctk.CTkProgressBar(
            xp_frame, width=400, height=12,
            corner_radius=6,
            progress_color=T["gold"],
            fg_color=T["bg_input"],
        )
        xp_bar.set(pet.xp_progress())
        xp_bar.pack(fill="x", pady=(4, 0))

        # Stats row
        stats = ctk.CTkFrame(self._pet_inner, fg_color="transparent")
        stats.pack(fill="x", pady=(10, 0))

        for label, value in [
            ("💬 Chats", str(pet.chats)),
            ("🎓 Practice", str(pet.practices)),
            ("🧠 Skills", str(len(pet.skills))),
            (f"{mood['emoji']} Mood", f"{pet.mood}/100"),
        ]:
            cell = ctk.CTkFrame(stats, fg_color=T["bg_input"], corner_radius=8)
            cell.pack(side="left", expand=True, fill="x", padx=3, pady=2)
            ctk.CTkLabel(cell, text=value, font=("Arial", 16, "bold"),
                         text_color=T["text_primary"]).pack(pady=(8, 0))
            ctk.CTkLabel(cell, text=label, font=("Arial", 10),
                         text_color=T["text_dim"]).pack(pady=(0, 8))

        # Mood message
        ctk.CTkLabel(
            self._pet_inner,
            text=f'"{mood["msg"]}"',
            font=("Arial", 12, "italic"),
            text_color=T["purple"],
        ).pack(pady=(10, 0))

    def _refresh_details(self):
        T = self.theme

        # Skills
        for w in self._skills_frame.winfo_children():
            w.destroy()

        if self._pet and self._pet.skills:
            for skill, score in sorted(self._pet.skills.items(), key=lambda x: -x[1]):
                row = ctk.CTkFrame(self._skills_frame, fg_color="transparent")
                row.pack(fill="x", pady=2)

                ctk.CTkLabel(row, text=skill.capitalize(),
                             font=("Arial", 12), text_color=T["text_primary"],
                             width=100, anchor="w").pack(side="left")

                bar = ctk.CTkProgressBar(row, width=200, height=8,
                                          corner_radius=4,
                                          progress_color=T["accent"],
                                          fg_color=T["bg_input"])
                bar.set(score)
                bar.pack(side="left", padx=8)

                ctk.CTkLabel(row, text=f"{score:.0%}",
                             font=("Arial", 11), text_color=T["text_secondary"],
                             ).pack(side="left")
        else:
            ctk.CTkLabel(self._skills_frame,
                         text="No skills yet — start chatting and practicing!",
                         font=("Arial", 11), text_color=T["text_dim"],
                         ).pack(anchor="w")

        # Achievements
        for w in self._ach_frame.winfo_children():
            w.destroy()

        if self._pet and self._pet.achievements:
            from core.tamagotchi import AITamagotchi
            # Map achievement keys back to labels
            all_checks = [
                ("first_chat",  "💬 First Words"),
                ("chatty",      "🗣️ Chatty"),
                ("social",      "🎉 Social"),
                ("first_train", "🎓 First Practice"),
                ("dedicated",   "📚 Dedicated"),
                ("scholar",     "🏆 Scholar"),
                ("level5",      "⭐ Level 5"),
                ("level10",     "🌟 Level 10"),
                ("level25",     "💫 Level 25"),
                ("level50",     "🌀 Level 50"),
                ("level100",    "♾️ Level 100"),
                ("polyglot",    "🌍 Polyglot"),
            ]
            labels = {k: v for k, v in all_checks}
            ach_text = "  ".join(
                labels.get(a, a) for a in self._pet.achievements
            )
            ctk.CTkLabel(self._ach_frame, text=ach_text,
                         font=("Arial", 12), text_color=T["gold"],
                         wraplength=500).pack(anchor="w")
        else:
            ctk.CTkLabel(self._ach_frame,
                         text="No achievements yet — keep going!",
                         font=("Arial", 11), text_color=T["text_dim"],
                         ).pack(anchor="w")

        # Evolution roadmap
        for w in self._evo_frame.winfo_children():
            w.destroy()

        current_level = self._pet.level if self._pet else 0
        for stage in STAGES:
            row = ctk.CTkFrame(self._evo_frame, fg_color="transparent")
            row.pack(fill="x", pady=1)

            reached = current_level >= stage["min_level"]
            color = T["gold"] if reached else T["text_dim"]

            ctk.CTkLabel(
                row, text=f"{stage['emoji']}  Lv.{stage['min_level']}",
                font=("Arial", 12, "bold" if reached else "normal"),
                text_color=color, width=80, anchor="w",
            ).pack(side="left")

            ctk.CTkLabel(
                row, text=f"{stage['name']} — {stage['desc']}",
                font=("Arial", 11),
                text_color=T["text_primary"] if reached else T["text_dim"],
            ).pack(side="left", padx=8)

            if reached:
                ctk.CTkLabel(row, text="✅", font=("Arial", 11)).pack(side="right")

    def _rename(self, _=None):
        if not self._pet:
            return
        dlg = ctk.CTkInputDialog(
            text=f"Name your AI (currently: {self._pet.get_display_name()}):",
            title="Name Your AI")
        name = dlg.get_input()
        if name and name.strip():
            self._pet.set_name(name.strip())
            self.refresh()

    def refresh(self):
        self._refresh_pet()
        self._refresh_details()

    def _start_tick(self):
        """Update mood every 60s while visible."""
        def _tick():
            if self._pet:
                self._pet.update_mood()
            self._tick_id = self.after(60_000, _tick)
        self._tick_id = self.after(60_000, _tick)
