# ============================================================
#  FreedomForge AI — ui/wizard.py
#  First-run setup — stupidly simple, 3 screens
# ============================================================

import json
import os
import customtkinter as ctk
from utils.paths import APP_VERSION, MODELS_DIR

CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".freedomforge", "config.json")

MIRANDA_QUOTES = [
    "Rome wasn't built in a day, and neither is a local AI!",
    "Fun fact: I don't need coffee to work. You probably do though.",
    "You have excellent taste in AI software.",
    "Loading genius... please hold.",
    "The future is local. And it's looking good.",
    "I searched the internet for wisdom. Then I remembered — we don't need the internet.",
]


class SetupWizard:
    def __init__(self, root, on_complete=None, theme_name="Midnight"):
        self.root = root
        self.on_complete = on_complete
        from assets.themes import get as get_theme
        self.T = get_theme(theme_name)
        self.root.title("FreedomForge AI — Setup")
        self.root.configure(fg_color=self.T["bg_deep"])
        for w in self.root.winfo_children():
            try:
                w.destroy()
            except Exception:
                pass
        self.steps = ["welcome", "terms", "ready"]
        self.step_idx = 0
        self.frame = ctk.CTkFrame(self.root, fg_color="transparent")
        self.frame.pack(expand=True, fill="both", padx=40, pady=30)
        self._show()

    def _clear(self):
        for w in self.frame.winfo_children():
            w.destroy()

    def _next(self):
        self.step_idx += 1
        if self.step_idx < len(self.steps):
            self._show()

    def _show(self):
        self._clear()
        step = self.steps[self.step_idx]
        {"welcome": self._welcome, "terms": self._terms, "ready": self._ready}[step]()

    def _welcome(self):
        T = self.T
        ctk.CTkLabel(self.frame, text="⚒️", font=("Arial", 60)).pack(pady=(30, 10))
        ctk.CTkLabel(self.frame, text="Welcome to FreedomForge AI",
                     font=("Arial", 24, "bold"), text_color=T["gold"]).pack(pady=(0, 8))
        ctk.CTkLabel(self.frame, text=(
            "Your own AI that runs entirely on your computer.\n\n"
            "No cloud. No subscription. No data collection.\n"
            "Everything stays on your machine. Forever.\n\n"
            "Let's get you set up — it only takes a minute."
        ), font=("Arial", 14), text_color=T["text_primary"],
            justify="center", wraplength=500).pack(pady=16)
        ctk.CTkLabel(self.frame, text="Dedicated to Miranda. She will never be forgotten.",
                     font=("Arial", 11, "italic"), text_color=T["purple"]).pack(pady=(10, 20))
        ctk.CTkButton(self.frame, text="Let's Go  →", width=200, height=45,
                      corner_radius=10, fg_color=T["accent"],
                      hover_color=T["accent_hover"], text_color="#ffffff",
                      font=("Arial", 15, "bold"), command=self._next).pack(pady=10)

    def _terms(self):
        T = self.T
        ctk.CTkLabel(self.frame, text="📋  Quick Terms",
                     font=("Arial", 20, "bold"), text_color=T["text_primary"]).pack(pady=(20, 12))
        ctk.CTkLabel(self.frame, text=(
            "FreedomForge AI is free and open source software.\n\n"
            "✅  Free for personal use. Always. No exceptions.\n\n"
            "✅  Your data never leaves your computer.\n\n"
            "✅  You own everything you create with it.\n\n"
            "⚖️  Commercial use (businesses over $250K revenue)\n"
            "     requires a separate license.\n\n"
            "🚫  You may not resell or rebrand this software.\n\n"
            "That's it. Simple."
        ), font=("Arial", 13), text_color=T["text_primary"],
            justify="left", wraplength=480).pack(padx=20, pady=10)
        ctk.CTkButton(self.frame, text="I Agree  →", width=200, height=45,
                      corner_radius=10, fg_color=T["accent"],
                      hover_color=T["accent_hover"], text_color="#ffffff",
                      font=("Arial", 15, "bold"), command=self._accept).pack(pady=16)

    def _accept(self):
        from core import config
        config.set("terms_accepted", True)
        self._next()

    def _ready(self):
        T = self.T
        ctk.CTkLabel(self.frame, text="✅", font=("Arial", 50)).pack(pady=(20, 6))
        ctk.CTkLabel(self.frame, text="You're Ready!",
                     font=("Arial", 22, "bold"), text_color=T["green"]).pack(pady=(0, 12))
        ctk.CTkLabel(self.frame, text=(
            "FreedomForge AI is set up and ready to go.\n\n"
            "Here's what to do next:\n\n"
            "1.  Go to the  📦 Models  tab\n"
            "2.  Pick a model (start with Mistral 7B or Phi-3.5)\n"
            "3.  Click Download — it'll take a few minutes\n"
            "4.  Once downloaded, click Load and start chatting!\n\n"
            "That's it. Your AI is ready."
        ), font=("Arial", 13), text_color=T["text_primary"],
            justify="left", wraplength=480).pack(padx=20, pady=6)
        ctk.CTkButton(self.frame, text="Launch FreedomForge  🚀", width=240, height=50,
                      corner_radius=12, fg_color=T["accent"],
                      hover_color=T["accent_hover"], text_color="#ffffff",
                      font=("Arial", 16, "bold"), command=self._finish).pack(pady=16)

    def _finish(self):
        self._save_config()
        if self.on_complete:
            self.on_complete()

    def _save_config(self):
        os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
        existing = {}
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE) as f:
                    existing = json.load(f)
            except Exception:
                pass
        existing.update({"first_run_complete": True, "models_path": str(MODELS_DIR)})
        try:
            with open(CONFIG_FILE, "w") as f:
                json.dump(existing, f, indent=2)
        except Exception:
            pass


def should_run_wizard() -> bool:
    if not os.path.exists(CONFIG_FILE):
        return True
    try:
        with open(CONFIG_FILE) as f:
            return not json.load(f).get("first_run_complete", False)
    except Exception:
        return True
