# ============================================================
#  FreedomForge AI — ui/components/sidebar.py
#  Navigation sidebar widget
# ============================================================

import customtkinter as ctk


class Sidebar(ctk.CTkFrame):
    """Left-side navigation panel."""

    def __init__(self, master, theme: dict, nav_items: list, on_switch, **kwargs):
        super().__init__(master, **kwargs)
        self.theme = theme
        self.on_switch = on_switch
        self.nav_btns = {}
        self._build(nav_items)

    def _build(self, nav_items):
        T = self.theme
        self.configure(width=204, corner_radius=0, fg_color=T["bg_sidebar"])
        self.pack_propagate(False)

        ctk.CTkFrame(self, height=2, fg_color=T["accent"]).pack(fill="x")

        ctk.CTkLabel(self, text="MENU", font=("Arial", 10, "bold"),
                     text_color=T["text_dim"]).pack(pady=(22, 6), padx=16, anchor="w")

        for icon, label, key in nav_items:
            b = ctk.CTkButton(
                self, text=f"  {icon}   {label}", font=("Arial", 13),
                height=54, corner_radius=0, fg_color="transparent", anchor="w",
                hover_color=T["bg_hover"], text_color=T["text_secondary"],
                command=lambda k=key: self.on_switch(k))
            b.pack(fill="x")
            self.nav_btns[key] = b

        ctk.CTkLabel(self, text="v0.1.0-alpha", font=("Arial", 9),
                     text_color=T["text_dim"]).pack(side="bottom", pady=12)

    def set_active(self, key: str):
        T = self.theme
        for k, btn in self.nav_btns.items():
            active = (k == key)
            btn.configure(
                fg_color=T["bg_hover"] if active else "transparent",
                text_color=T["text_primary"] if active else T["text_secondary"],
                font=("Arial", 13, "bold") if active else ("Arial", 13))
