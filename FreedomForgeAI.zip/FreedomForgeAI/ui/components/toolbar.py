# ============================================================
#  FreedomForge AI — ui/components/toolbar.py
#  Top application toolbar
# ============================================================

import customtkinter as ctk


class Toolbar(ctk.CTkFrame):
    """Top application toolbar with logo, mode badge and control toggles."""

    def __init__(self, master, theme: dict, callbacks: dict, **kwargs):
        super().__init__(master, **kwargs)
        self.theme = theme
        self.callbacks = callbacks or {}
        self._build()

    def _build(self):
        T = self.theme
        self.configure(fg_color=T["bg_topbar"], height=66, corner_radius=0)
        self.pack_propagate(False)

        self.logo_lbl = ctk.CTkLabel(
            self, text="⚒️  FreedomForge AI",
            font=("Arial", 22, "bold"), text_color=T["gold"], cursor="hand2")
        self.logo_lbl.pack(side="left", padx=24)

        self.mode_badge = ctk.CTkLabel(
            self, text="", font=("Arial", 12, "bold"), text_color=T["accent2"])
        self.mode_badge.pack(side="left", padx=4)

        self.tog_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.tog_frame.pack(side="right", padx=8)
        self._build_toggles()

    def _build_toggles(self):
        T = self.theme
        self.net_var = ctk.BooleanVar(value=False)
        self.net_sw = ctk.CTkSwitch(
            self.tog_frame, text="🌐 Net Kill", variable=self.net_var,
            onvalue=True, offvalue=False,
            command=self.callbacks.get("on_network", lambda: None),
            width=40, height=22, font=("Arial", 10, "bold"),
            text_color=T["red"], button_color=T["red"], button_hover_color=T["red"])
        self.net_sw.pack(side="right", padx=(0, 14))

        ctk.CTkFrame(self.tog_frame, width=1, height=22,
                     fg_color=T["divider"]).pack(side="right", padx=6)

        toggles_config = [
            ("🖱️ Agent", "agent", self.callbacks.get("on_agent", lambda: None), False),
            ("🔊 Voice", "tts", self.callbacks.get("on_tts", lambda: None), False),
            ("🎤 Mic", "voice", self.callbacks.get("on_voice", lambda: None), False),
        ]
        self.toggle_vars = {}
        self.toggle_switches = {}
        for label, key, cmd, default in reversed(toggles_config):
            var = ctk.BooleanVar(value=default)
            self.toggle_vars[key] = var
            sw = ctk.CTkSwitch(
                self.tog_frame, text=label, variable=var,
                onvalue=True, offvalue=False, command=cmd,
                width=40, height=22, font=("Arial", 10),
                text_color=T["text_dim"], button_color=T["accent"],
                button_hover_color=T["accent_hover"])
            sw.pack(side="right", padx=(0, 10))
            self.toggle_switches[key] = sw

    def update_mode_badge(self, text: str):
        try: self.mode_badge.configure(text=text)
        except Exception: pass

    def get_toggles(self):
        return self.toggle_switches
