# ============================================================
#  FreedomForge AI — ui/components/message_bubble.py
#  Chat message bubble widget
# ============================================================

import customtkinter as ctk


class MessageBubble(ctk.CTkFrame):
    """A single chat message bubble."""

    def __init__(self, master, role: str, content: str, theme: dict, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.role = role.lower()
        self.theme = theme
        self._content = content
        self._build()

    def _build(self):
        T = self.theme
        if self.role in ("user", "you"):
            sender, name_color = "You", T["text_you"]
            bubble_fg, text_color = T["bg_hover"], T["text_primary"]
            pad = (60, 10)
        elif self.role in ("ai", "assistant", "freedomforge"):
            sender, name_color = "FreedomForge", T["accent2"]
            bubble_fg, text_color = T["bg_card"], T["text_ai"]
            pad = (10, 60)
        else:
            sender, name_color = "System", T["text_sys"]
            bubble_fg, text_color = T["bg_card"], T["text_sys"]
            pad = (10, 60)

        self.bubble = ctk.CTkFrame(self, fg_color=bubble_fg, corner_radius=18)
        self.bubble.pack(fill="x", padx=pad, pady=6)

        header = ctk.CTkFrame(self.bubble, fg_color="transparent")
        header.pack(fill="x", padx=16, pady=(12, 4))

        self.name_lbl = ctk.CTkLabel(header, text=sender,
            font=("Arial", 12, "bold"), text_color=name_color, anchor="w")
        self.name_lbl.pack(side="left")

        self.copy_btn = ctk.CTkButton(header, text="📋 Copy", width=80, height=26,
            corner_radius=12, fg_color=T["bg_hover"], hover_color=T["bg_card"],
            text_color=T["text_dim"], font=("Arial", 11), command=self._copy)
        self.copy_btn.pack_forget()

        self.content_lbl = ctk.CTkLabel(self.bubble, text=self._content,
            font=("Arial", 13), text_color=text_color, wraplength=520,
            justify="left", anchor="w")
        self.content_lbl.pack(fill="x", padx=16, pady=(2, 16))

        for w in [self.bubble, self.content_lbl, self.name_lbl]:
            w.bind("<Enter>", lambda e: self.copy_btn.pack(side="right", padx=4))
            w.bind("<Leave>", lambda e: self.copy_btn.pack_forget())

    def _copy(self):
        try:
            self.clipboard_clear()
            self.clipboard_append(self._content)
        except Exception: pass

    def append_token(self, token: str):
        self._content += token
        self.content_lbl.configure(text=self._content)
