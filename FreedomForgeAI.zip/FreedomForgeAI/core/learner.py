# ============================================================
#  FreedomForge AI — core/learner.py
#  Self-improvement engine — ingest text, PDFs, transcripts,
#  extract knowledge, generate training examples automatically.
#
#  Feed it:  docs, articles, code, YouTube transcripts, books
#  It will:  chunk → summarize → extract Q&A pairs → store as
#            training examples for LoRA fine-tuning
# ============================================================

import json
import os
import re
import threading
import time
from pathlib import Path
from typing import Callable, List, Optional, Tuple
from core import logger

try:
    import numpy as np
    NP_OK = True
except ImportError:
    np = None
    NP_OK = False

from core.embeddings import embed_text, embed_batch, cosine_search, is_available as embeddings_available

from utils.paths import APP_ROOT, EXAMPLES_DIR, TRAINING_DIR

KNOWLEDGE_DIR = APP_ROOT / "knowledge"
INGESTED_FILE = KNOWLEDGE_DIR / "ingested.jsonl"
QA_FILE         = KNOWLEDGE_DIR / "qa_pairs.jsonl"
EMBEDDINGS_FILE = KNOWLEDGE_DIR / "embeddings.npy"

# Chunking settings
CHUNK_SIZE    = 1500   # chars per chunk
CHUNK_OVERLAP = 200    # overlap between chunks


class KnowledgeIngestor:
    """
    Ingests text content, chunks it, and either:
    1. Stores it as retrievable knowledge (RAG-lite)
    2. Generates instruction-output pairs for training
    3. Both
    """

    def __init__(self):
        self._lock = threading.Lock()
        os.makedirs(str(KNOWLEDGE_DIR), exist_ok=True)
        os.makedirs(str(EXAMPLES_DIR), exist_ok=True)

    # ── Ingest text content ──────────────────────────────────

    def ingest_text(
        self,
        text: str,
        source: str = "manual",
        title: str = "",
        on_progress: Callable[[str], None] = None,
        on_done: Callable[[int], None] = None,
    ) -> None:
        """Ingest raw text in a background thread."""

        def _work():
            try:
                if on_progress:
                    on_progress(f"Chunking {len(text):,} chars...")

                chunks = self._chunk_text(text)
                if on_progress:
                    on_progress(f"Processing {len(chunks)} chunks...")

                stored = 0
                for i, chunk in enumerate(chunks):
                    if len(chunk.strip()) < 50:
                        continue

                    entry = {
                        "time":   time.strftime("%Y-%m-%d %H:%M:%S"),
                        "source": source,
                        "title":  title,
                        "chunk":  i,
                        "total":  len(chunks),
                        "text":   chunk,
                    }

                    with self._lock:
                        with open(INGESTED_FILE, "a") as f:
                            f.write(json.dumps(entry) + "\n")
                    stored += 1

                    if on_progress and i % 5 == 0:
                        on_progress(f"Stored {stored}/{len(chunks)} chunks...")

                logger.info(
                    f"Ingested: {title or source} — "
                    f"{stored} chunks from {len(text):,} chars"
                )
                if on_done:
                    on_done(stored)

            except Exception as e:
                logger.error(f"Ingest failed: {e}")
                if on_done:
                    on_done(0)

        threading.Thread(target=_work, daemon=True).start()

    def ingest_file(
        self,
        path: str,
        on_progress: Callable[[str], None] = None,
        on_done: Callable[[int], None] = None,
    ) -> None:
        """Ingest a text file, PDF, or other readable format."""
        p = Path(path).expanduser().resolve()
        if not p.exists():
            if on_done:
                on_done(0)
            return

        title = p.name
        suffix = p.suffix.lower()

        try:
            if suffix == ".pdf":
                text = self._read_pdf(p)
            elif suffix in (".txt", ".md", ".rst", ".log", ".csv"):
                text = p.read_text(encoding="utf-8", errors="replace")
            elif suffix in (".py", ".js", ".rs", ".go", ".c", ".cpp", ".h"):
                text = p.read_text(encoding="utf-8", errors="replace")
                title = f"Code: {p.name}"
            elif suffix == ".json":
                text = p.read_text(encoding="utf-8", errors="replace")
            elif suffix in (".html", ".htm"):
                text = self._strip_html(
                    p.read_text(encoding="utf-8", errors="replace")
                )
            else:
                # Try reading as text
                text = p.read_text(encoding="utf-8", errors="replace")

            if text and len(text.strip()) > 50:
                self.ingest_text(
                    text, source=str(p), title=title,
                    on_progress=on_progress, on_done=on_done
                )
            else:
                if on_done:
                    on_done(0)

        except Exception as e:
            logger.error(f"File ingest failed ({path}): {e}")
            if on_done:
                on_done(0)

    # ── Generate Q&A training pairs from ingested knowledge ──

    def generate_qa_pairs(
        self,
        model_fn: Callable[[str], str],
        max_chunks: int = 50,
        on_progress: Callable[[str, int], None] = None,
        on_done: Callable[[int], None] = None,
    ) -> None:
        """
        Use the loaded model to generate instruction-output pairs
        from ingested knowledge chunks. This is the self-improvement
        pipeline — the AI reads what you fed it and creates its own
        study material.

        model_fn: function that takes a prompt string and returns
                  the model's response string (blocking).
        """

        def _work():
            if not INGESTED_FILE.exists():
                if on_done:
                    on_done(0)
                return

            chunks = []
            try:
                with open(INGESTED_FILE) as f:
                    for line in f:
                        if line.strip():
                            chunks.append(json.loads(line))
            except Exception:
                if on_done:
                    on_done(0)
                return

            # Take most recent chunks
            chunks = chunks[-max_chunks:]
            total_qa = 0

            for i, chunk in enumerate(chunks):
                text = chunk.get("text", "")
                if len(text) < 100:
                    continue

                # Ask the model to generate Q&A from the content
                prompt = (
                    "Read this text and generate exactly 2 question-answer "
                    "pairs that test understanding of the key concepts. "
                    "Format each as:\n"
                    "Q: <question>\n"
                    "A: <answer>\n\n"
                    f"Text:\n{text[:1200]}\n\n"
                    "Q&A pairs:"
                )

                try:
                    response = model_fn(prompt)
                    pairs = self._parse_qa(response)

                    for question, answer in pairs:
                        if len(question) > 10 and len(answer) > 10:
                            qa_entry = {
                                "time":        time.strftime("%Y-%m-%d %H:%M:%S"),
                                "source":      chunk.get("source", ""),
                                "instruction": question,
                                "output":      answer,
                            }

                            with self._lock:
                                with open(QA_FILE, "a") as f:
                                    f.write(json.dumps(qa_entry) + "\n")

                                # Also save to training examples
                                example = {
                                    "instruction": question,
                                    "output":      answer,
                                    "skill":       "knowledge",
                                    "source":      "learner",
                                    "time":        time.strftime("%Y-%m-%d %H:%M:%S"),
                                }
                                with open(
                                    EXAMPLES_DIR / "learned_examples.jsonl", "a"
                                ) as f:
                                    f.write(json.dumps(example) + "\n")

                            total_qa += 1

                    if on_progress:
                        on_progress(
                            f"Chunk {i+1}/{len(chunks)} — {total_qa} Q&A pairs",
                            total_qa
                        )

                except Exception as e:
                    logger.debug(f"QA generation failed for chunk {i}: {e}")

                time.sleep(0.2)  # don't hammer the model

            logger.info(f"Generated {total_qa} Q&A pairs from {len(chunks)} chunks")
            if on_done:
                on_done(total_qa)

        threading.Thread(target=_work, daemon=True).start()

    # ── Retrieve relevant knowledge for a query ──────────────

    def search_knowledge(self, query: str, max_results: int = 5) -> List[str]:
        """
        Semantic vector search if embeddings available,
        otherwise falls back to keyword search.
        """
        # Try semantic search first
        if NP_OK and embeddings_available() and EMBEDDINGS_FILE.exists():
            try:
                query_vec = embed_text(query)
                if query_vec is not None:
                    stored_vecs = np.load(EMBEDDINGS_FILE)
                    if stored_vecs is not None and stored_vecs.shape[0] > 0:
                        top = cosine_search(query_vec, stored_vecs, top_k=max_results)
                        chunks = []
                        with open(INGESTED_FILE) as f:
                            for line in f:
                                if line.strip():
                                    chunks.append(json.loads(line).get("text", ""))
                        results = []
                        for idx, score in top:
                            if idx < len(chunks):
                                results.append(chunks[idx][:800])
                        if results:
                            return results
            except Exception as e:
                logger.debug(f"Semantic search failed: {e}, falling back to keyword")

        # Keyword fallback
        if not INGESTED_FILE.exists():
            return []

        query_words = set(query.lower().split())
        scored = []

        try:
            with open(INGESTED_FILE) as f:
                for line in f:
                    if not line.strip():
                        continue
                    entry = json.loads(line)
                    text = entry.get("text", "")
                    text_lower = text.lower()
                    score = sum(
                        1 for w in query_words
                        if len(w) > 2 and w in text_lower
                    )
                    if score > 0:
                        scored.append((score, text[:500]))

            scored.sort(key=lambda x: x[0], reverse=True)
            return [text for _, text in scored[:max_results]]
        except Exception:
            return []

    # ── Helpers ──────────────────────────────────────────────

    def _chunk_text(self, text: str) -> List[str]:
        """Split text into overlapping chunks."""
        chunks = []
        # Clean up whitespace
        text = re.sub(r'\n{3,}', '\n\n', text)

        # Try to split on paragraph boundaries first
        paragraphs = text.split("\n\n")
        current = ""

        for para in paragraphs:
            if len(current) + len(para) < CHUNK_SIZE:
                current += para + "\n\n"
            else:
                if current.strip():
                    chunks.append(current.strip())
                current = para + "\n\n"

        if current.strip():
            chunks.append(current.strip())

        # If chunks are still too big, split by sentences
        final = []
        for chunk in chunks:
            if len(chunk) <= CHUNK_SIZE * 1.5:
                final.append(chunk)
            else:
                # Split by sentence
                sentences = re.split(r'(?<=[.!?])\s+', chunk)
                sub = ""
                for sent in sentences:
                    if len(sub) + len(sent) < CHUNK_SIZE:
                        sub += sent + " "
                    else:
                        if sub.strip():
                            final.append(sub.strip())
                        sub = sent + " "
                if sub.strip():
                    final.append(sub.strip())

        return final

    def _parse_qa(self, text: str) -> List[Tuple[str, str]]:
        """Parse Q: / A: pairs from model output."""
        pairs = []
        q_pattern = re.compile(r'Q:\s*(.+?)(?=\nA:)', re.DOTALL)
        a_pattern = re.compile(r'A:\s*(.+?)(?=\nQ:|\Z)', re.DOTALL)

        questions = q_pattern.findall(text)
        answers = a_pattern.findall(text)

        for q, a in zip(questions, answers):
            q = q.strip()
            a = a.strip()
            if q and a:
                pairs.append((q, a))

        return pairs

    def _read_pdf(self, path: Path) -> str:
        """Extract text from PDF."""
        try:
            import fitz  # PyMuPDF
            doc = fitz.open(str(path))
            text = ""
            for page in doc:
                text += page.get_text() + "\n\n"
            doc.close()
            return text
        except ImportError:
            pass

        try:
            # Fallback: pdfplumber
            import pdfplumber
            text = ""
            with pdfplumber.open(str(path)) as pdf:
                for page in pdf.pages:
                    t = page.extract_text()
                    if t:
                        text += t + "\n\n"
            return text
        except ImportError:
            pass

        logger.warning("No PDF library — install PyMuPDF or pdfplumber")
        return ""

    def _strip_html(self, html: str) -> str:
        """Strip HTML tags."""
        text = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL)
        text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = re.sub(r'\s+', ' ', text)
        return text.strip()

    # ── Stats ────────────────────────────────────────────────

    def get_stats(self) -> dict:
        chunks = 0
        qa_pairs = 0
        if INGESTED_FILE.exists():
            try:
                with open(INGESTED_FILE) as f:
                    chunks = sum(1 for _ in f)
            except Exception:
                pass
        if QA_FILE.exists():
            try:
                with open(QA_FILE) as f:
                    qa_pairs = sum(1 for _ in f)
            except Exception:
                pass

        learned = 0
        lf = EXAMPLES_DIR / "learned_examples.jsonl"
        if lf.exists():
            try:
                with open(lf) as f:
                    learned = sum(1 for _ in f)
            except Exception:
                pass

        return {
            "ingested_chunks":   chunks,
            "qa_pairs":          qa_pairs,
            "learned_examples":  learned,
            "knowledge_dir":     str(KNOWLEDGE_DIR),
        }


# ── Global instance ─────────────────────────────────────────
_learner = KnowledgeIngestor()

def get_learner() -> KnowledgeIngestor:
    return _learner
