# ============================================================
#  FreedomForge AI — core/embeddings.py
#  Semantic vector search with sentence-transformers.
#  Lazy-loads model, CPU only, graceful fallback.
# ============================================================

import os
import threading
from pathlib import Path
from typing import List, Optional, Tuple

try:
    import numpy as np
    NP_OK = True
except ImportError:
    np = None
    NP_OK = False

from utils.paths import APP_ROOT

_MODEL = None
_MODEL_LOCK = threading.Lock()
_CACHE_DIR = APP_ROOT / "models" / "sentence_transformers"


def _get_model():
    global _MODEL
    if _MODEL is not None:
        return _MODEL
    with _MODEL_LOCK:
        if _MODEL is not None:
            return _MODEL
        try:
            from sentence_transformers import SentenceTransformer
            os.makedirs(_CACHE_DIR, exist_ok=True)
            _MODEL = SentenceTransformer(
                "all-MiniLM-L6-v2",
                cache_folder=str(_CACHE_DIR),
                device="cpu",
            )
            _MODEL.encode("warmup", convert_to_numpy=True)
            return _MODEL
        except ImportError:
            return None
        except Exception:
            return None


def is_available() -> bool:
    return _get_model() is not None


def embed_text(text: str):
    model = _get_model()
    if model is None or not NP_OK:
        return None
    try:
        return model.encode(text, convert_to_numpy=True).astype(np.float32)
    except Exception:
        return None


def embed_batch(texts: List[str]):
    model = _get_model()
    if model is None or not texts or not NP_OK:
        return None
    try:
        return model.encode(texts, convert_to_numpy=True).astype(np.float32)
    except Exception:
        return None


def cosine_search(query_vec, stored_vecs, top_k: int = 5) -> List[Tuple[int, float]]:
    if not NP_OK or query_vec is None or stored_vecs is None or stored_vecs.shape[0] == 0:
        return []
    norm_q = query_vec / (np.linalg.norm(query_vec) + 1e-8)
    norms = np.linalg.norm(stored_vecs, axis=1, keepdims=True) + 1e-8
    norm_stored = stored_vecs / norms
    similarities = np.dot(norm_stored, norm_q)
    if similarities.shape[0] <= top_k:
        idx = np.argsort(-similarities)
    else:
        idx = np.argpartition(-similarities, top_k)[:top_k]
        idx = idx[np.argsort(-similarities[idx])]
    return [(int(i), float(similarities[i])) for i in idx[:top_k]]
