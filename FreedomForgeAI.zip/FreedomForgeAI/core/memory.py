# ============================================================
#  FreedomForge AI — core/memory.py
#  Long-term memory — remembers conversations, extracts facts,
#  auto-trims old data, injects relevant context into prompts.
#
#  How it works:
#  ─────────────
#  1. Every conversation turn is saved to memory.jsonl
#  2. Periodically, the model summarizes old conversations
#     into compressed "core memories" (key facts, preferences)
#  3. Before each response, relevant memories are retrieved
#     and injected into the system prompt
#  4. Old raw messages get pruned; summaries persist forever
#  5. User facts (name, preferences, etc.) are pinned and
#     never trimmed
# ============================================================

import json
import os
import time
import threading
from pathlib import Path
from typing import List, Dict, Optional, Callable
from core import logger

from utils.paths import APP_ROOT

MEMORY_DIR   = APP_ROOT / "memory"
RAW_FILE     = MEMORY_DIR / "conversations.jsonl"
FACTS_FILE   = MEMORY_DIR / "facts.json"
SUMMARY_FILE = MEMORY_DIR / "summaries.jsonl"

# Limits
MAX_RAW_ENTRIES    = 500    # keep last N raw messages before trimming
MAX_CONTEXT_TOKENS = 800    # approx tokens of memory to inject
MAX_FACTS          = 100    # max pinned facts
TRIM_INTERVAL      = 300    # seconds between auto-trim checks


class MemoryStore:
    """
    Persistent memory for the AI — remembers what you've talked about,
    what you like, what you've asked, and learns over time.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._facts: Dict[str, str] = {}     # key→value pinned facts
        self._summaries: List[dict] = []      # compressed old conversations
        self._trim_thread = None
        self._running = False
        os.makedirs(str(MEMORY_DIR), exist_ok=True)
        self._load_facts()
        self._load_summaries()

    # ── Fact management (pinned, never trimmed) ──────────────

    def _load_facts(self):
        if FACTS_FILE.exists():
            try:
                with open(FACTS_FILE) as f:
                    self._facts = json.load(f)
            except Exception:
                self._facts = {}

    def _save_facts(self):
        try:
            with open(FACTS_FILE, "w") as f:
                json.dump(self._facts, f, indent=2)
        except Exception as e:
            logger.error(f"Memory facts save failed: {e}")

    def set_fact(self, key: str, value: str) -> None:
        """Pin a fact (e.g., user's name, preferences)."""
        with self._lock:
            self._facts[key.lower().strip()] = value.strip()
            if len(self._facts) > MAX_FACTS:
                # Remove oldest entries
                keys = list(self._facts.keys())
                for k in keys[:len(keys) - MAX_FACTS]:
                    del self._facts[k]
            self._save_facts()

    def get_fact(self, key: str) -> Optional[str]:
        return self._facts.get(key.lower().strip())

    def get_all_facts(self) -> Dict[str, str]:
        return dict(self._facts)

    def remove_fact(self, key: str) -> bool:
        with self._lock:
            removed = self._facts.pop(key.lower().strip(), None)
            if removed is not None:
                self._save_facts()
            return removed is not None

    # ── Raw conversation logging ─────────────────────────────

    def log_message(self, role: str, content: str) -> None:
        """Log a single message to the conversation history."""
        entry = {
            "time":    time.strftime("%Y-%m-%d %H:%M:%S"),
            "ts":      time.time(),
            "role":    role,
            "content": content[:2000],
        }
        try:
            with open(RAW_FILE, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception as e:
            logger.error(f"Memory log failed: {e}")

    def get_recent_messages(self, n: int = 50) -> List[dict]:
        """Get the N most recent raw messages."""
        if not RAW_FILE.exists():
            return []
        try:
            lines = RAW_FILE.read_text().strip().split("\n")
            entries = []
            for line in lines[-n:]:
                if line.strip():
                    entries.append(json.loads(line))
            return entries
        except Exception:
            return []

    # ── Summaries (compressed old conversations) ─────────────

    def _load_summaries(self):
        if SUMMARY_FILE.exists():
            try:
                self._summaries = []
                for line in SUMMARY_FILE.read_text().strip().split("\n"):
                    if line.strip():
                        self._summaries.append(json.loads(line))
            except Exception:
                self._summaries = []

    def add_summary(self, summary: str, period: str = "") -> None:
        """Add a compressed summary of old conversations."""
        entry = {
            "time":    time.strftime("%Y-%m-%d %H:%M:%S"),
            "period":  period,
            "summary": summary[:1000],
        }
        with self._lock:
            self._summaries.append(entry)
            try:
                with open(SUMMARY_FILE, "a") as f:
                    f.write(json.dumps(entry) + "\n")
            except Exception as e:
                logger.error(f"Summary save failed: {e}")

    # ── Context building (inject into system prompt) ─────────

    def build_context(self) -> str:
        """
        Build a memory context string to inject into the system prompt.
        Combines pinned facts + recent summaries + recent messages.
        Stays under MAX_CONTEXT_TOKENS (~words).
        """
        parts = []
        budget = MAX_CONTEXT_TOKENS

        # 1. Pinned facts (highest priority)
        if self._facts:
            facts_str = "What I know about you:\n"
            for k, v in list(self._facts.items())[:30]:
                line = f"- {k}: {v}\n"
                facts_str += line
            parts.append(facts_str)
            budget -= len(facts_str.split())

        # 2. Recent summaries (compressed history)
        if self._summaries and budget > 100:
            parts.append("\nPast conversation summaries:")
            for s in self._summaries[-5:]:
                text = s.get("summary", "")
                words = len(text.split())
                if words > budget:
                    break
                parts.append(f"- [{s.get('period', '?')}] {text}")
                budget -= words

        # 3. Recent raw messages (short-term recall)
        if budget > 50:
            recent = self.get_recent_messages(10)
            if recent:
                parts.append("\nRecent conversation context:")
                for msg in recent[-6:]:
                    role = msg.get("role", "?")
                    text = msg.get("content", "")[:150]
                    line = f"- {role}: {text}"
                    words = len(line.split())
                    if words > budget:
                        break
                    parts.append(line)
                    budget -= words

        return "\n".join(parts) if parts else ""

    # ── Auto-extraction of facts from conversation ───────────

    def extract_facts_from_message(self, user_msg: str, ai_response: str) -> None:
        """
        Simple rule-based extraction of user facts from conversation.
        Runs in background thread so it doesn't block chat.
        """
        def _extract():
            msg = user_msg.lower()

            # Name patterns
            for pattern in ["my name is ", "i'm ", "i am ", "call me "]:
                if pattern in msg:
                    after = user_msg[msg.index(pattern) + len(pattern):]
                    name = after.split(".")[0].split(",")[0].split("!")[0].strip()
                    if 1 < len(name) < 40 and name[0].isupper():
                        self.set_fact("user_name", name)

            # Location
            for pattern in ["i live in ", "i'm from ", "i am from ", "i'm based in "]:
                if pattern in msg:
                    after = user_msg[msg.index(pattern) + len(pattern):]
                    loc = after.split(".")[0].split(",")[0].strip()
                    if 2 < len(loc) < 50:
                        self.set_fact("location", loc)

            # Job/role
            for pattern in ["i work as ", "i'm a ", "i am a ", "my job is "]:
                if pattern in msg:
                    after = user_msg[msg.index(pattern) + len(pattern):]
                    job = after.split(".")[0].split(",")[0].strip()
                    if 2 < len(job) < 60:
                        self.set_fact("role", job)

            # Preferences
            for pattern in ["i prefer ", "i like ", "i love ", "my favorite "]:
                if pattern in msg:
                    after = user_msg[msg.index(pattern) + len(pattern):]
                    pref = after.split(".")[0].split(",")[0].strip()[:80]
                    if len(pref) > 3:
                        key = f"preference_{pattern.strip().replace(' ', '_')}"
                        self.set_fact(key, pref)

            # OS / tech
            for pattern in ["i use ", "i run ", "i'm on "]:
                if pattern in msg:
                    after = user_msg[msg.index(pattern) + len(pattern):]
                    tech = after.split(".")[0].split(",")[0].strip()[:50]
                    if len(tech) > 2:
                        self.set_fact(f"tech_{tech[:20]}", tech)

        threading.Thread(target=_extract, daemon=True).start()

    # ── Auto-trimming ────────────────────────────────────────

    def trim(self, model_summarize: Callable = None) -> int:
        """
        Trim old raw messages. If a model summarize function is
        provided, compress old messages into a summary first.
        Returns number of entries trimmed.
        """
        if not RAW_FILE.exists():
            return 0

        try:
            lines = RAW_FILE.read_text().strip().split("\n")
        except Exception:
            return 0

        if len(lines) <= MAX_RAW_ENTRIES:
            return 0

        # Split into old (to trim) and recent (to keep)
        trim_count = len(lines) - MAX_RAW_ENTRIES
        old_lines = lines[:trim_count]
        keep_lines = lines[trim_count:]

        # Try to summarize old messages before discarding
        if model_summarize and old_lines:
            try:
                old_entries = []
                for line in old_lines:
                    if line.strip():
                        old_entries.append(json.loads(line))

                # Build a condensed text of old conversations
                old_text = "\n".join(
                    f"{e.get('role', '?')}: {e.get('content', '')[:200]}"
                    for e in old_entries[-30:]  # summarize last 30 of the old batch
                )

                if old_text.strip():
                    summary = model_summarize(old_text)
                    if summary:
                        period = (
                            f"{old_entries[0].get('time', '?')} to "
                            f"{old_entries[-1].get('time', '?')}"
                        )
                        self.add_summary(summary, period)
                        logger.info(
                            f"Memory trimmed: {trim_count} entries → summary"
                        )
            except Exception as e:
                logger.error(f"Memory summarize failed: {e}")

        # Write back only the recent entries
        with self._lock:
            try:
                with open(RAW_FILE, "w") as f:
                    for line in keep_lines:
                        f.write(line + "\n")
            except Exception as e:
                logger.error(f"Memory trim write failed: {e}")

        return trim_count

    def start_auto_trim(self, model_summarize: Callable = None):
        """Start background auto-trim thread."""
        if self._running:
            return
        self._running = True

        def _loop():
            while self._running:
                time.sleep(TRIM_INTERVAL)
                try:
                    trimmed = self.trim(model_summarize)
                    if trimmed:
                        logger.info(f"Auto-trim: {trimmed} old messages compressed")
                except Exception as e:
                    logger.error(f"Auto-trim error: {e}")

        self._trim_thread = threading.Thread(target=_loop, daemon=True)
        self._trim_thread.start()
        logger.info("Memory auto-trim started")

    def stop_auto_trim(self):
        self._running = False

    # ── Stats ────────────────────────────────────────────────

    def get_stats(self) -> dict:
        raw_count = 0
        if RAW_FILE.exists():
            try:
                with open(RAW_FILE) as f:
                    raw_count = sum(1 for _ in f)
            except Exception:
                pass
        return {
            "raw_messages":  raw_count,
            "facts":         len(self._facts),
            "summaries":     len(self._summaries),
            "memory_dir":    str(MEMORY_DIR),
        }

    def clear_all(self) -> None:
        """Nuclear option — wipe all memory."""
        with self._lock:
            self._facts = {}
            self._summaries = []
            for f in (RAW_FILE, FACTS_FILE, SUMMARY_FILE):
                try:
                    f.unlink(missing_ok=True)
                except Exception:
                    pass
        logger.info("All memory cleared")


# ── Global instance ─────────────────────────────────────────
_memory = MemoryStore()

def get_memory() -> MemoryStore:
    return _memory
