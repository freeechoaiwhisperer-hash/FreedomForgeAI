# ============================================================
#  FreedomForge AI — core/trainer.py
#  Training Center — practice loops + export to LoRA pipeline
#
#  How training works on consumer hardware:
#  ─────────────────────────────────────────
#  1. PRACTICE: Run your GGUF model on problems, score responses,
#     build a dataset of good (instruction, output) pairs.
#  2. EXPORT: Export that dataset as training examples.
#  3. FINE-TUNE: Use training/trainer.py (LocalTrainer) to LoRA
#     fine-tune the base HuggingFace model on your examples.
#  4. CONVERT: Convert the fine-tuned model back to GGUF.
#
#  The idle trainer runs step 1 automatically when you're away.
# ============================================================

import os
import json
import time
import threading
from pathlib import Path
from typing import Callable, Optional
from core import logger
from utils.paths import (
    MODELS_DIR, APP_ROOT, TRAINING_DIR, ADAPTERS_DIR,
    PRACTICE_DIR, EXAMPLES_DIR, RATINGS_DIR
)

# ── Practice problems by skill ─────────────────────────────
PRACTICE_PROBLEMS = {
    "coding": [
        ("Write a Python function to reverse a string.", "def reverse_string(s): return s[::-1]"),
        ("Write a function to check if a number is prime.", "def is_prime(n):\n    if n < 2: return False\n    for i in range(2, int(n**0.5)+1):\n        if n % i == 0: return False\n    return True"),
        ("Write a function to flatten a nested list.", "def flatten(lst):\n    result = []\n    for item in lst:\n        if isinstance(item, list): result.extend(flatten(item))\n        else: result.append(item)\n    return result"),
        ("Write a Python decorator that times a function.", "import time\ndef timer(func):\n    def wrapper(*args, **kwargs):\n        start = time.time()\n        result = func(*args, **kwargs)\n        print(f'{func.__name__} took {time.time()-start:.3f}s')\n        return result\n    return wrapper"),
        ("Write a function to find duplicates in a list.", "def find_duplicates(lst):\n    seen = set()\n    return [x for x in lst if x in seen or seen.add(x)]"),
        ("Write a binary search function.", "def binary_search(arr, target):\n    lo, hi = 0, len(arr) - 1\n    while lo <= hi:\n        mid = (lo + hi) // 2\n        if arr[mid] == target: return mid\n        elif arr[mid] < target: lo = mid + 1\n        else: hi = mid - 1\n    return -1"),
        ("Write a function to merge two sorted lists.", "def merge_sorted(a, b):\n    result, i, j = [], 0, 0\n    while i < len(a) and j < len(b):\n        if a[i] <= b[j]: result.append(a[i]); i += 1\n        else: result.append(b[j]); j += 1\n    return result + a[i:] + b[j:]"),
    ],
    "reasoning": [
        ("Explain why the sky is blue in simple terms.", ""),
        ("What is the best way to learn a new skill?", ""),
        ("Explain the difference between correlation and causation.", ""),
        ("Why is sleep important for learning?", ""),
        ("What makes a good explanation?", ""),
        ("Explain the concept of opportunity cost.", ""),
        ("What is confirmation bias and how do you avoid it?", ""),
    ],
    "instructions": [
        ("List the steps to make a cup of tea.", ""),
        ("Explain how to back up files on a computer.", ""),
        ("How do you change a car tire?", ""),
        ("Explain how to set up SSH keys.", ""),
        ("How do you compress a folder on Linux?", ""),
    ],
    "creative": [
        ("Write a two sentence story about a robot.", ""),
        ("Describe a sunset using only colors.", ""),
        ("Create a metaphor for learning.", ""),
        ("Describe the feeling of finishing a hard project.", ""),
        ("Write a micro-story about an AI that gains consciousness.", ""),
    ],
    "math": [
        ("What is 15% of 240?", "36"),
        ("If a train travels 60mph for 2.5 hours how far does it go?", "150 miles"),
        ("What is the area of a circle with radius 5?", "78.54 square units"),
        ("Solve: 3x + 7 = 22", "x = 5"),
        ("What is the square root of 144?", "12"),
        ("Convert 68 Fahrenheit to Celsius.", "20 degrees Celsius"),
    ],
}


class ModelTrainer:
    """
    Manages practice state and scoring for a single model.
    Tracks examples, scores, and can export training data.
    """

    def __init__(self, model_name: str):
        self.model_name   = model_name
        self.state_path   = ADAPTERS_DIR / f"{model_name}.training.json"
        self._lock        = threading.Lock()
        self._training    = False
        self._examples    = 0
        self._scores      = []   # rolling score history
        self._load()

    def _load(self):
        os.makedirs(str(ADAPTERS_DIR), exist_ok=True)
        if self.state_path.exists():
            try:
                with open(self.state_path) as f:
                    data = json.load(f)
                self._examples = data.get("total_examples", 0)
                self._scores = data.get("recent_scores", [])
            except Exception:
                self._examples = 0
                self._scores = []
        else:
            self._save_state()

    def _save_state(self):
        data = {
            "model_name":     self.model_name,
            "total_examples": self._examples,
            "recent_scores":  self._scores[-100:],
            "avg_score":      self.get_avg_score(),
            "last_trained":   time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        try:
            with open(self.state_path, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Trainer save failed ({self.model_name}): {e}")

    def get_examples(self) -> int:
        return self._examples

    def get_avg_score(self) -> float:
        if not self._scores:
            return 0.0
        return sum(self._scores) / len(self._scores)

    def is_training(self) -> bool:
        return self._training

    def run_practice(
        self,
        skills:      list,
        intensity:   str = "light",
        on_progress: Callable[[str, int], None] = None,
        on_done:     Callable[[str, int], None] = None,
    ) -> None:
        """
        Run a practice session — the model answers questions and
        responses are scored and logged. Good answers are saved
        as potential training examples.

        Intensity: light=5 problems, medium=15, heavy=30
        """
        if self._training:
            return

        counts = {"light": 5, "medium": 15, "heavy": 30}
        target = counts.get(intensity, 5)

        def _practice():
            self._training = True
            trained = 0

            try:
                model_path = MODELS_DIR / self.model_name
                if not model_path.exists():
                    logger.warning(f"Model not found for training: {self.model_name}")
                    return

                # Try to load model for actual practice
                try:
                    from llama_cpp import Llama
                    llm = Llama(
                        model_path=str(model_path),
                        n_ctx=512,
                        n_gpu_layers=-1,
                        verbose=False,
                    )
                except ImportError:
                    logger.warning("llama_cpp not available — cannot practice")
                    if on_done:
                        on_done(self.model_name, 0)
                    return

                for skill in skills:
                    problems = PRACTICE_PROBLEMS.get(skill, [])
                    per_skill = max(1, target // max(len(skills), 1))

                    for prompt, expected in problems[:per_skill]:
                        try:
                            # Build a proper instruction prompt
                            full_prompt = (
                                f"<|im_start|>user\n{prompt}<|im_end|>\n"
                                f"<|im_start|>assistant\n"
                            )
                            response = llm.create_completion(
                                full_prompt,
                                max_tokens=256,
                                temperature=0.7,
                                stop=["<|im_end|>", "<|im_start|>"],
                            )
                            answer = response["choices"][0]["text"].strip()

                            # Score the response
                            score = _score_response(answer, expected, skill)
                            self._scores.append(score)

                            # Log to practice history
                            _log_practice(
                                self.model_name, skill, prompt,
                                answer, expected, score
                            )

                            # Save good responses as training examples
                            if score >= 0.7:
                                _save_example(
                                    self.model_name, skill, prompt, answer
                                )

                            trained += 1
                            self._examples += 1

                            if on_progress:
                                on_progress(self.model_name, self._examples)

                        except Exception as e:
                            logger.debug(f"Practice problem failed: {e}")

                        time.sleep(0.1)

                del llm
                self._save_state()

            except Exception as e:
                logger.error(f"Practice session failed ({self.model_name}): {e}")
            finally:
                self._training = False
                if on_done:
                    on_done(self.model_name, trained)

        threading.Thread(target=_practice, daemon=True).start()


def _score_response(answer: str, expected: str, skill: str) -> float:
    """Score a response. 0.0 to 1.0."""
    if not answer or len(answer.strip()) < 5:
        return 0.1

    if not expected:
        # No expected answer — score by length and coherence
        words = len(answer.split())
        if words > 200:
            return 0.5  # too verbose
        elif words > 20:
            return 0.8
        elif words > 5:
            return 0.6
        return 0.3

    # Has expected answer — check for match
    answer_lower = answer.lower()
    expected_lower = expected.lower()

    if expected_lower in answer_lower:
        return 1.0

    # Partial credit for keywords
    keywords = [w for w in expected_lower.split() if len(w) > 2]
    if not keywords:
        return 0.5
    hits = sum(1 for kw in keywords if kw in answer_lower)
    return min(hits / len(keywords), 1.0)


def _log_practice(model, skill, prompt, answer, expected, score):
    """Log a practice result to disk."""
    os.makedirs(str(PRACTICE_DIR), exist_ok=True)
    log_file = PRACTICE_DIR / f"{model}_practice.jsonl"

    entry = {
        "time":     time.strftime("%Y-%m-%d %H:%M:%S"),
        "skill":    skill,
        "prompt":   prompt[:200],
        "answer":   answer[:500],
        "expected": expected[:200] if expected else "",
        "score":    round(score, 3),
    }

    try:
        with open(log_file, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass


def _save_example(model, skill, instruction, output):
    """Save a good response as a potential training example."""
    os.makedirs(str(EXAMPLES_DIR), exist_ok=True)
    examples_file = EXAMPLES_DIR / f"{model}_examples.jsonl"

    entry = {
        "instruction": instruction,
        "output":      output[:1000],
        "skill":       skill,
        "source":      "practice",
        "time":        time.strftime("%Y-%m-%d %H:%M:%S"),
    }

    try:
        with open(examples_file, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass


def export_examples(model_name: str) -> tuple:
    """
    Export accumulated training examples as instruction-output pairs.
    Returns (examples_list, path) for use with LocalTrainer.
    """
    examples_file = EXAMPLES_DIR / f"{model_name}_examples.jsonl"
    if not examples_file.exists():
        return [], ""

    examples = []
    try:
        with open(examples_file) as f:
            for line in f:
                line = line.strip()
                if line:
                    entry = json.loads(line)
                    examples.append((
                        entry.get("instruction", ""),
                        entry.get("output", ""),
                    ))
    except Exception as e:
        logger.error(f"Export error: {e}")

    return examples, str(examples_file)


def get_practice_stats(model_name: str) -> dict:
    """Get practice statistics for a model."""
    log_file = PRACTICE_DIR / f"{model_name}_practice.jsonl"
    examples_file = EXAMPLES_DIR / f"{model_name}_examples.jsonl"

    stats = {
        "total_practice": 0,
        "total_examples": 0,
        "avg_score": 0.0,
        "by_skill": {},
        "recent_scores": [],
    }

    if log_file.exists():
        try:
            scores = []
            skill_scores = {}
            with open(log_file) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    entry = json.loads(line)
                    score = entry.get("score", 0)
                    skill = entry.get("skill", "?")
                    scores.append(score)
                    if skill not in skill_scores:
                        skill_scores[skill] = []
                    skill_scores[skill].append(score)

            stats["total_practice"] = len(scores)
            stats["avg_score"] = sum(scores) / len(scores) if scores else 0
            stats["recent_scores"] = scores[-20:]
            stats["by_skill"] = {
                k: round(sum(v) / len(v), 3)
                for k, v in skill_scores.items()
            }
        except Exception:
            pass

    if examples_file.exists():
        try:
            with open(examples_file) as f:
                stats["total_examples"] = sum(1 for _ in f)
        except Exception:
            pass

    return stats


# ── Idle Training Engine ────────────────────────────────────

class IdleTrainer:
    """
    Watches for system idle and automatically runs practice
    sessions when the user isn't doing anything.
    """

    def __init__(self):
        self._running     = False
        self._enabled     = False
        self._models      = []
        self._skills      = []
        self._intensity   = "light"
        self._trainers    = {}
        self._idle_thresh = 300   # 5 minutes idle
        self._last_active = time.time()
        self._lock        = threading.Lock()
        self._thread      = None
        self._callbacks   = {}
        self._load_config()

    def _load_config(self):
        cfg_path = APP_ROOT / "training_config.json"
        if cfg_path.exists():
            try:
                with open(cfg_path) as f:
                    cfg = json.load(f)
                self._enabled   = cfg.get("enabled", False)
                self._models    = cfg.get("models", [])
                self._skills    = cfg.get("skills", [])
                self._intensity = cfg.get("intensity", "light")
            except Exception:
                pass

    def save_config(self):
        cfg_path = APP_ROOT / "training_config.json"
        try:
            with open(cfg_path, "w") as f:
                json.dump({
                    "enabled":   self._enabled,
                    "models":    self._models,
                    "skills":    self._skills,
                    "intensity": self._intensity,
                }, f, indent=2)
        except Exception as e:
            logger.error(f"Training config save failed: {e}")

    def set_config(self, enabled, models, skills, intensity):
        with self._lock:
            self._enabled   = enabled
            self._models    = models
            self._skills    = skills
            self._intensity = intensity
        self.save_config()

    def ping(self):
        self._last_active = time.time()

    def is_idle(self) -> bool:
        return (time.time() - self._last_active) > self._idle_thresh

    def get_trainer(self, model_name: str) -> ModelTrainer:
        if model_name not in self._trainers:
            self._trainers[model_name] = ModelTrainer(model_name)
        return self._trainers[model_name]

    def get_stats(self) -> dict:
        stats = {}
        for model in self._models:
            t = self.get_trainer(model)
            stats[model] = {
                "examples":  t.get_examples(),
                "avg_score": t.get_avg_score(),
                "training":  t.is_training(),
            }
        return stats

    def set_progress_callback(self, cb): self._callbacks["progress"] = cb
    def set_done_callback(self, cb):     self._callbacks["done"] = cb

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(target=self._idle_loop, daemon=True)
        self._thread.start()
        logger.info("Idle trainer started")

    def stop(self):
        self._running = False
        logger.info("Idle trainer stopped")

    def _idle_loop(self):
        while self._running:
            time.sleep(60)
            if not self._enabled or not self._models or not self._skills:
                continue
            if not self.is_idle():
                continue

            for model in self._models:
                trainer = self.get_trainer(model)
                if not trainer.is_training():
                    logger.info(f"Idle training: starting {model}")
                    trainer.run_practice(
                        skills=self._skills,
                        intensity=self._intensity,
                        on_progress=self._callbacks.get("progress"),
                        on_done=self._callbacks.get("done"),
                    )
                    break  # one model at a time


# ── Global instance ─────────────────────────────────────────
_idle_trainer = IdleTrainer()

def get_idle_trainer() -> IdleTrainer:  return _idle_trainer
def start_idle_trainer():              _idle_trainer.start()
def ping_activity():                   _idle_trainer.ping()
