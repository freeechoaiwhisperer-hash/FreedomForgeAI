# ============================================================
#  FreedomForge AI — core/tts.py
#  Voice input (Whisper local STT) and output (pyttsx3 TTS)
#
#  Privacy-first: Whisper runs 100% locally on your machine.
#  Google Speech is available as an explicit opt-in fallback
#  only if Whisper is not installed.
# ============================================================

import os
import threading
import tempfile
from typing import Callable, Optional
from core import logger

# ── TTS engine ───────────────────────────────────────────────
try:
    import pyttsx3
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False

# ── STT engines — prefer local Whisper ───────────────────────
try:
    import whisper as _whisper
    WHISPER_AVAILABLE = True
except ImportError:
    _whisper = None
    WHISPER_AVAILABLE = False

try:
    import speech_recognition as sr
    import pyaudio as _pa
    SR_AVAILABLE = True
except ImportError:
    sr = None
    SR_AVAILABLE = False

_tts_engine = None
_tts_lock   = threading.Lock()

_whisper_model = None
_whisper_lock  = threading.Lock()
_whisper_model_name = "base"   # tiny | base | small | medium | large


# ── TTS (voice output) ───────────────────────────────────────

def init_tts() -> bool:
    global _tts_engine
    if not TTS_AVAILABLE:
        return False
    try:
        with _tts_lock:
            _tts_engine = pyttsx3.init()
            _tts_engine.setProperty("rate", 165)
            _tts_engine.setProperty("volume", 0.9)
        return True
    except Exception:
        _tts_engine = None
        return False


def speak(text: str) -> None:
    """Speak text in a background thread."""
    if _tts_engine is None:
        return

    def _speak():
        with _tts_lock:
            try:
                _tts_engine.say(text[:500])
                _tts_engine.runAndWait()
            except Exception:
                pass

    threading.Thread(target=_speak, daemon=True).start()


def tts_available() -> bool:
    return TTS_AVAILABLE and _tts_engine is not None


# ── Whisper model management ────────────────────────────────

def _load_whisper():
    """Lazy-load the Whisper model on first use."""
    global _whisper_model
    if _whisper_model is not None:
        return _whisper_model
    with _whisper_lock:
        if _whisper_model is not None:
            return _whisper_model
        try:
            logger.info(f"Loading Whisper model: {_whisper_model_name}")
            _whisper_model = _whisper.load_model(_whisper_model_name)
            logger.info("Whisper model loaded")
            return _whisper_model
        except Exception as e:
            logger.error(f"Whisper load failed: {e}")
            return None


def set_whisper_model(name: str) -> None:
    """Change Whisper model size. Takes effect on next listen()."""
    global _whisper_model_name, _whisper_model
    if name in ("tiny", "base", "small", "medium", "large"):
        _whisper_model_name = name
        _whisper_model = None  # force reload


# ── Voice input ──────────────────────────────────────────────

def listen(
    on_result: Callable[[str], None],
    on_error:  Callable[[str], None],
    timeout:   int = 8,
    force_google: bool = False,
) -> None:
    """Listen for speech in a background thread.

    Uses local Whisper by default. Falls back to Google Speech API
    only if Whisper is not installed AND the caller allows it.
    """
    if not SR_AVAILABLE:
        on_error(
            "🎤 Microphone requires PyAudio.\n\n"
            "On Windows: the installer handles this automatically.\n"
            "On Linux: run  sudo apt install portaudio19-dev  then  pip install pyaudio\n"
            "On macOS: run  brew install portaudio  then  pip install pyaudio"
        )
        return

    use_whisper = WHISPER_AVAILABLE and not force_google

    def _listen():
        try:
            recognizer = sr.Recognizer()
            recognizer.energy_threshold        = 300
            recognizer.dynamic_energy_threshold = True

            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.4)
                audio = recognizer.listen(
                    source,
                    timeout=timeout,
                    phrase_time_limit=30,
                )

            if use_whisper:
                text = _transcribe_whisper(audio)
            else:
                # Google fallback — sends audio to Google servers.
                # User has explicitly opted in via the mic toggle.
                logger.warning(
                    "Using Google Speech API — audio leaves your machine. "
                    "Install openai-whisper for local STT."
                )
                text = recognizer.recognize_google(audio)

            if text:
                on_result(text)
            else:
                on_error("Could not understand audio")

        except sr.WaitTimeoutError:
            on_error("No speech detected")
        except sr.UnknownValueError:
            on_error("Could not understand audio")
        except sr.RequestError as e:
            on_error(f"Speech service error: {e}")
        except Exception as e:
            on_error(str(e))

    threading.Thread(target=_listen, daemon=True).start()


def _transcribe_whisper(audio) -> Optional[str]:
    """Transcribe audio using local Whisper model."""
    model = _load_whisper()
    if model is None:
        raise RuntimeError(
            "Whisper model failed to load. "
            "Run: pip install openai-whisper"
        )

    # Write audio to a temp WAV file for Whisper
    raw_data = audio.get_wav_data()
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        f.write(raw_data)
        tmp_path = f.name

    try:
        result = model.transcribe(
            tmp_path,
            language="en",
            fp16=False,    # CPU-safe; GPU users can override
        )
        text = result.get("text", "").strip()
        return text if text else None
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


def sr_available() -> bool:
    return SR_AVAILABLE


def stt_engine() -> str:
    """Return which STT engine will be used."""
    if WHISPER_AVAILABLE:
        return "whisper"
    elif SR_AVAILABLE:
        return "google"
    else:
        return "none"
