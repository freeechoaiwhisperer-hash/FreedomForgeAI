# ============================================================
#  FreedomForge AI — core/token_counter.py
#  Token estimation and context trimming to prevent overflow
# ============================================================

def estimate_tokens(text: str) -> int:
    """Rough token estimate: 1 token ≈ 4 characters."""
    if not text or not isinstance(text, str):
        return 0
    return len(text) // 4 + 3


def count_messages(messages: list) -> int:
    """Count approximate tokens in list of {'role': , 'content': } messages."""
    if not messages:
        return 0
    total = sum(estimate_tokens(m.get("content", "") if isinstance(m, dict) else str(m)) for m in messages)
    total += len(messages) * 5
    return total


def trim_messages(messages: list, max_tokens: int) -> list:
    """Trim conversation history to fit max_tokens. Keeps most recent."""
    if not messages:
        return []
    trimmed = list(messages)
    while len(trimmed) > 2 and count_messages(trimmed) > max_tokens:
        trimmed.pop(0)
    return trimmed
