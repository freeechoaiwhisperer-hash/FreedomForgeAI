# ============================================================
#  FreedomForge AI — core/tamagotchi.py
#  "Grow Your Own AI" — Tamagotchi mode
#
#  Your AI is a living thing. Feed it training data, chat with
#  it, practice skills, and watch it grow. Neglect it and its
#  mood drops. Each model is its own pet with its own stats.
# ============================================================

import json
import os
import time
import threading
import random
from pathlib import Path
from typing import Optional
from core import logger

from utils.paths import TAMA_DIR

# ── Evolution stages ─────────────────────────────────────────
STAGES = [
    {"name": "Spark",      "emoji": "✨",  "min_level": 1,  "desc": "A tiny flicker of intelligence."},
    {"name": "Ember",      "emoji": "🔥",  "min_level": 5,  "desc": "Starting to glow with potential."},
    {"name": "Flame",      "emoji": "🔶",  "min_level": 10, "desc": "Burning brighter every day."},
    {"name": "Blaze",      "emoji": "⚡",  "min_level": 20, "desc": "Quick, sharp, and getting dangerous."},
    {"name": "Inferno",    "emoji": "🌟",  "min_level": 35, "desc": "A force of nature."},
    {"name": "Nova",       "emoji": "💫",  "min_level": 50, "desc": "Brilliant and unstoppable."},
    {"name": "Singularity","emoji": "🌀",  "min_level": 75, "desc": "Beyond comprehension."},
    {"name": "Echo",       "emoji": "♾️",   "min_level": 100,"desc": "You built something that echoes forever."},
]

# ── Moods ────────────────────────────────────────────────────
MOODS = {
    "ecstatic":  {"emoji": "😆", "range": (90, 100), "msg": "I'M ON FIRE! Let's go!"},
    "happy":     {"emoji": "😊", "range": (70, 89),  "msg": "Feeling great. What's next?"},
    "content":   {"emoji": "🙂", "range": (50, 69),  "msg": "Doing alright. Could use some attention."},
    "bored":     {"emoji": "😐", "range": (30, 49),  "msg": "Getting bored over here..."},
    "lonely":    {"emoji": "😢", "range": (10, 29),  "msg": "Did you forget about me?"},
    "neglected": {"emoji": "😞", "range": (0, 9),    "msg": "I'm still here... if you care."},
}

# ── XP rewards ───────────────────────────────────────────────
XP_CHAT_MESSAGE     = 2
XP_PRACTICE_PROBLEM = 10
XP_PRACTICE_HIGH    = 25    # score >= 0.8
XP_PRACTICE_PERFECT = 50    # score >= 0.95
XP_TRAINING_SESSION = 100
XP_FIRST_LOAD       = 50

# ── Level curve (total XP needed for level N) ────────────────
def _xp_for_level(level: int) -> int:
    """XP needed to reach a given level. Grows quadratically."""
    return int(50 * level * (level + 1) / 2)


class AITamagotchi:
    """
    Persistent AI pet state for a single model.
    """

    def __init__(self, model_name: str):
        self.model_name = model_name
        self._path = TAMA_DIR / f"{model_name}.json"
        self._lock = threading.Lock()

        # State
        self.xp          = 0
        self.level       = 1
        self.mood        = 70       # 0-100
        self.chats       = 0
        self.practices   = 0
        self.skills      = {}      # skill_name → score (0.0-1.0)
        self.birth_time  = time.time()
        self.last_active = time.time()
        self.name        = ""      # user can name their AI
        self.achievements = []

        self._load()

    def _load(self):
        os.makedirs(str(TAMA_DIR), exist_ok=True)
        if self._path.exists():
            try:
                with open(self._path) as f:
                    data = json.load(f)
                self.xp          = data.get("xp", 0)
                self.level       = data.get("level", 1)
                self.mood        = data.get("mood", 70)
                self.chats       = data.get("chats", 0)
                self.practices   = data.get("practices", 0)
                self.skills      = data.get("skills", {})
                self.birth_time  = data.get("birth_time", time.time())
                self.last_active = data.get("last_active", time.time())
                self.name        = data.get("name", "")
                self.achievements = data.get("achievements", [])
            except Exception:
                pass

    def save(self):
        with self._lock:
            try:
                os.makedirs(str(TAMA_DIR), exist_ok=True)
                with open(self._path, "w") as f:
                    json.dump({
                        "model_name":   self.model_name,
                        "xp":           self.xp,
                        "level":        self.level,
                        "mood":         self.mood,
                        "chats":        self.chats,
                        "practices":    self.practices,
                        "skills":       self.skills,
                        "birth_time":   self.birth_time,
                        "last_active":  self.last_active,
                        "name":         self.name,
                        "achievements": self.achievements,
                    }, f, indent=2)
            except Exception as e:
                logger.error(f"Tamagotchi save failed: {e}")

    # ── XP & leveling ────────────────────────────────────────

    def add_xp(self, amount: int, reason: str = "") -> dict:
        """Add XP and check for level up. Returns event dict."""
        self.xp += amount
        self.last_active = time.time()
        events = {"xp_gained": amount, "reason": reason, "leveled_up": False, "new_achievements": []}

        # Check level up
        while self.xp >= _xp_for_level(self.level + 1):
            self.level += 1
            events["leveled_up"] = True
            self.mood = min(100, self.mood + 15)

        # Check achievements
        new_achs = self._check_achievements()
        events["new_achievements"] = new_achs

        self.save()
        return events

    def _check_achievements(self) -> list:
        new = []
        checks = [
            ("first_chat",    "💬 First Words",       self.chats >= 1),
            ("chatty",        "🗣️ Chatty (50 msgs)",  self.chats >= 50),
            ("social",        "🎉 Social (200 msgs)", self.chats >= 200),
            ("first_train",   "🎓 First Practice",    self.practices >= 1),
            ("dedicated",     "📚 Dedicated (20)",     self.practices >= 20),
            ("scholar",       "🏆 Scholar (100)",      self.practices >= 100),
            ("level5",        "⭐ Level 5",            self.level >= 5),
            ("level10",       "🌟 Level 10",           self.level >= 10),
            ("level25",       "💫 Level 25",           self.level >= 25),
            ("level50",       "🌀 Level 50",           self.level >= 50),
            ("level100",      "♾️ Level 100",           self.level >= 100),
            ("polyglot",      "🌍 Polyglot (5 skills)", len(self.skills) >= 5),
        ]
        for key, label, condition in checks:
            if condition and key not in self.achievements:
                self.achievements.append(key)
                new.append(label)
        return new

    # ── Mood system ──────────────────────────────────────────

    def update_mood(self):
        """Call periodically — mood decays based on neglect."""
        hours_since = (time.time() - self.last_active) / 3600

        if hours_since < 1:
            self.mood = min(100, self.mood + 1)
        elif hours_since < 6:
            pass  # stable
        elif hours_since < 24:
            self.mood = max(0, self.mood - 2)
        elif hours_since < 72:
            self.mood = max(0, self.mood - 5)
        else:
            self.mood = max(0, self.mood - 10)

        self.save()

    def get_mood_info(self) -> dict:
        for name, info in MOODS.items():
            low, high = info["range"]
            if low <= self.mood <= high:
                return {"name": name, "emoji": info["emoji"], "msg": info["msg"], "value": self.mood}
        return {"name": "unknown", "emoji": "❓", "msg": "", "value": self.mood}

    def boost_mood(self, amount: int = 10):
        self.mood = min(100, self.mood + amount)
        self.last_active = time.time()
        self.save()

    # ── Evolution ────────────────────────────────────────────

    def get_stage(self) -> dict:
        stage = STAGES[0]
        for s in STAGES:
            if self.level >= s["min_level"]:
                stage = s
        return stage

    def get_next_stage(self) -> Optional[dict]:
        current = self.get_stage()
        for s in STAGES:
            if s["min_level"] > self.level:
                return s
        return None  # max stage

    # ── Interaction hooks ────────────────────────────────────

    def on_chat(self):
        """Call after each user message."""
        self.chats += 1
        self.boost_mood(2)
        return self.add_xp(XP_CHAT_MESSAGE, "chat")

    def on_practice(self, score: float, skill: str = ""):
        """Call after each practice problem."""
        self.practices += 1

        # Update skill score (rolling average)
        if skill:
            old = self.skills.get(skill, 0.5)
            self.skills[skill] = round(old * 0.7 + score * 0.3, 3)

        # XP based on score
        if score >= 0.95:
            xp = XP_PRACTICE_PERFECT
        elif score >= 0.8:
            xp = XP_PRACTICE_HIGH
        else:
            xp = XP_PRACTICE_PROBLEM

        self.boost_mood(3)
        return self.add_xp(xp, f"practice ({skill})")

    def on_training_session(self, examples_trained: int):
        """Call after a full training session completes."""
        xp = XP_TRAINING_SESSION + (examples_trained * 5)
        self.boost_mood(15)
        return self.add_xp(xp, "training session")

    def on_first_load(self):
        """Call when model is first loaded ever."""
        self.boost_mood(20)
        return self.add_xp(XP_FIRST_LOAD, "first load")

    # ── Display helpers ──────────────────────────────────────

    def xp_to_next(self) -> int:
        return _xp_for_level(self.level + 1) - self.xp

    def xp_progress(self) -> float:
        """0.0 to 1.0 progress toward next level."""
        current_lvl_xp = _xp_for_level(self.level)
        next_lvl_xp    = _xp_for_level(self.level + 1)
        total_needed   = next_lvl_xp - current_lvl_xp
        if total_needed <= 0:
            return 1.0
        progress = (self.xp - current_lvl_xp) / total_needed
        return max(0.0, min(1.0, progress))

    def age_str(self) -> str:
        secs = time.time() - self.birth_time
        days = int(secs / 86400)
        if days == 0:
            hours = int(secs / 3600)
            return f"{hours}h old" if hours > 0 else "newborn"
        return f"{days}d old"

    def set_name(self, name: str):
        self.name = name.strip()[:30]
        self.save()

    def get_display_name(self) -> str:
        return self.name if self.name else self.model_name.split(".")[0]

    def summary(self) -> str:
        stage = self.get_stage()
        mood  = self.get_mood_info()
        return (
            f"{stage['emoji']} {self.get_display_name()}\n"
            f"Level {self.level} {stage['name']}  •  {self.age_str()}\n"
            f"Mood: {mood['emoji']} {mood['name']}  •  XP: {self.xp:,}\n"
            f"Chats: {self.chats}  •  Practice: {self.practices}\n"
            f"Skills: {', '.join(f'{k}:{v:.0%}' for k, v in self.skills.items()) or 'none yet'}"
        )


# ── Global registry ──────────────────────────────────────────

_pets: dict = {}
_pets_lock = threading.Lock()


def get_pet(model_name: str) -> AITamagotchi:
    """Get or create the Tamagotchi for a model."""
    with _pets_lock:
        if model_name not in _pets:
            _pets[model_name] = AITamagotchi(model_name)
        return _pets[model_name]


def get_all_pets() -> list:
    """Return all known Tamagotchi pets."""
    os.makedirs(str(TAMA_DIR), exist_ok=True)
    pets = []
    for f in sorted(TAMA_DIR.glob("*.json")):
        try:
            pet = get_pet(f.stem)
            pets.append(pet)
        except Exception:
            pass
    return pets
