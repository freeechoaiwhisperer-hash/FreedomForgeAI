# FreedomForge AI — training package
